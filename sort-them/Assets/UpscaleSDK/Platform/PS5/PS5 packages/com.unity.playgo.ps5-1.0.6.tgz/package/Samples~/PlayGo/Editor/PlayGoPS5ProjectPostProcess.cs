using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

#if UNITY_PS5
namespace PS5PlayGoSample
{
    public static class PS5PlayGoBuildParams
    {
        static readonly string[] m_SampleStreamingAssetPaths = new string[] { "PlayGo Sample/StreamingAssets", "Samples/PlayGo/StreamingAssets" };
        static readonly string[] m_SampleStreamingAssetFiles = new string[] { "testfile0.txt", "testfile1.txt", "testfile2.txt", "testfile3.txt", "testfile4.txt", "testfile5.txt", "testfile6.txt" };
        static readonly string[] m_SampleSceSysPaths = new string[] { "PlayGo Sample/SystemFiles~/sce_sys", "Samples/PlayGo/SystemFiles~/sce_sys" };
        static readonly string[] m_SampleSystemFilePaths = new string[] { "PlayGo Sample/SystemFiles~", "Samples/PlayGo/SystemFiles~" };
        static readonly string m_PlayGoEmulationFile = "playgo-chunks-text-files.xml";

        static public string[] StreamingAssetPaths()
        {
            return m_SampleStreamingAssetPaths;
        }

        static public string[] StreamingAssetFiles()
        {
            return m_SampleStreamingAssetFiles;
        }

        static public string[] SceSysPaths()
        {
            return m_SampleSceSysPaths;
        }

        public static string FindPlayGoEmulationFile()
        {
            return PS5PlayGoSample.SetPlatformOptionsPS5.SearchForFile(Application.dataPath, m_PlayGoEmulationFile, true, m_SampleSystemFilePaths);
        }
    }

#if UNITY_2022_1_OR_NEWER
    // Class PlayGoPS5ProjectPostProcess implements UnityEditor.PS5.IPostProcessPS5PrepareStagingArea.OnPrepareStagingArea to
    // allow insertion of a PlayGo emulation file into a PC hosted build.
    //
    public class PlayGoPS5ProjectPostProcess : UnityEditor.PS5.IPostProcessPS5PrepareStagingArea
    {
        public bool OnPrepareStagingArea(string projectFolder, string outputFolder, UnityEditor.PS5.PS5BuildSubtarget buildSubtarget, BuildOptions buildOptions)
        {
            Debug.Log($"[ps5] Called OnPrepareStagingArea(\"{projectFolder}\", \"{outputFolder}\") with buildType {buildSubtarget}\n");
            Debug.Log($"[ps5] ... BuildOptions: {buildOptions}\n");

            if (buildSubtarget == UnityEditor.PS5.PS5BuildSubtarget.PCHosted)
            {
                string playGoEmulationFile = PS5PlayGoBuildParams.FindPlayGoEmulationFile();
                if (File.Exists(playGoEmulationFile))
                {
                    // The playgo chunks file goes in the root of the working directory.
                    Debug.Log($"[ps5] ... Copying PlayGo emulation file \"{playGoEmulationFile}\" to PC hosted build.\n");
                    File.Copy(playGoEmulationFile, Path.Combine(outputFolder, "playgo-chunks.xml"), true);
                }
                else
                {
                    Debug.LogError($"[ps5] ... PlayGo emulation file not found: \"{playGoEmulationFile}\"\n");
                }
            }

            return true;
        }

        // This interface class derives from IOrderedCallback so we must implement callbackOrder().
        public int callbackOrder { get { return 1; } }
    }

    // Class PlayGoPS5CreateGP5Project implements UnityEditor.PS5.IPostProcessPS5CreateGP5Project.OnCreateGP5Project to
    // allow custom GP5 project creation for enabling PlayGo chunks in a PS5 package.
    //
    public class PlayGoPS5CreateGP5Project : UnityEditor.PS5.IPostProcessPS5CreateGP5Project
    {
        public UnityEditor.PS5.Gp5Project OnCreateGP5Project(List<UnityEditor.PS5.TargetFileMapping> targetFileMappings, string packagePasscode, UnityEditor.PS5.PS5BuildSubtarget buildSubtarget, BuildOptions buildOptions)
        {
            Debug.Log($"[ps5] Called OnCreateGP5Project() with buildType {buildSubtarget}\n");

            string playGoEmulationFile = PS5PlayGoBuildParams.FindPlayGoEmulationFile();
            if (!File.Exists(playGoEmulationFile))
            {
                // A play-go emulation file has not been set so assume that play-go is not required and fallback to the built-in GP5 project generation.
                Debug.Log($"[ps5] .. PS5BuildParams.m_PlayGoEmulationFilePath is not valid, skipping PlayGo setup.\n");
                return null;
            }

            Debug.Log($"[ps5] .. Creating GP5 Project using PlayGo emulation file to set chunks and scenarios: \"{playGoEmulationFile}\"\n");

            // Create a GP5 Project using the PlayGo emulation file to assign chunk IDs to files.
            UnityEditor.PS5.Gp5Project gp5 = GenerateGP5(targetFileMappings, packagePasscode, playGoEmulationFile);
            return gp5;
        }

        // This interface class derives from IOrderedCallback so we must implement callbackOrder().
        public int callbackOrder { get { return 1; } }

        UnityEditor.PS5.Gp5Project GenerateGP5(List<UnityEditor.PS5.TargetFileMapping> targetFileMappings, string packagePasscode, string playGoEmulationFile)
        {
            DateTime creationDate = DateTime.Now;

            // Create a GP5 Project.
            UnityEditor.PS5.Gp5Project gp5 = new UnityEditor.PS5.Gp5Project();
            gp5.creationDate = creationDate;
            gp5.packagePasscode = packagePasscode;
            gp5.volumeType = UnityEditor.PS5.Gp5Project.VolumeType.prospero_app;
            gp5.InitDefaultElements();

            PlayGoEmuFile emuFile = new PlayGoEmuFile();
            if (!string.IsNullOrEmpty(playGoEmulationFile))
            {
                // Read and parse the play-go emulation file.
                emuFile.Read(playGoEmulationFile);

                // Set the chunk info from the emulation file into the GP5 project.
                gp5.SetChunkInfo(emuFile.ChunkInfo);
            }

            // Add the files to the gp5 project with a chunk ID lookup for each file.
            gp5.AddFiles(targetFileMappings, filePath => emuFile.FindChunkIDForFile(filePath));

            return gp5;
        }
    }

#else

    // Class PlayGoPS5ProjectPostProcess implements UnityEditor.PS5.IPostProcessPS5.OnPostProcessPS5 to
    // allow insertion of a PlayGo emulation file into a PC hosted build.
    //
    public class PlayGoPS5ProjectPostProcess : UnityEditor.PS5.IPostProcessPS5
    {
        public void OnPostProcessPS5(string projectFolder, string outputFolder)
        {
            Debug.Log($"[ps5] Called OnPostProcessPS5(\"{projectFolder}\", \"{outputFolder}\"), buildType is assumed to be PCHosted\n");

            // Assume build sub-target is UnityEditor.PS5.PS5BuildSubtarget.PCHosted.
            string playGoEmulationFile = PS5PlayGoBuildParams.FindPlayGoEmulationFile();
            if (File.Exists(playGoEmulationFile))
            {
                // The playgo chunks file goes in the root of the working directory.
                Debug.Log($"[ps5] ... Copying PlayGo emulation file \"{playGoEmulationFile}\" to PC hosted build.\n");
                File.Copy(playGoEmulationFile, Path.Combine(outputFolder, "playgo-chunks.xml"), true);
            }
            else
            {
                Debug.LogError($"[ps5] ... PlayGo emulation file not found: \"{playGoEmulationFile}\"\n");
            }
        }

        public int callbackOrder { get { return 1; } }
    }

#endif
}

#endif
