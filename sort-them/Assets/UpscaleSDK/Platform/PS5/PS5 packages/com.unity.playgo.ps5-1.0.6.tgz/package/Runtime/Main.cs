
using System;
using System.Runtime.InteropServices;
using System.Collections.Generic;

using Unity.PlayGo.PS5.Initialization;
using Unity.PlayGo.PS5.Aysnc;
using Unity.PlayGo.PS5.Internal;

namespace Unity.PlayGo.PS5
{
    /// <summary>
    /// Main entry point to the PlayGo system and initialization
    /// </summary>
    public class Main
    {
        #region DLL Import

        [DllImport(LibraryInfo.LibraryName)]
        private static extern void Playgo_PrxInitialize(out NativeInitResult initResult, out APIResult result);

        [DllImport(LibraryInfo.LibraryName)]
        private static extern void Playgo_PrxShutDown();

        [DllImport(LibraryInfo.LibraryName)]
        private static extern int Playgo_PrxUpdate();

        #endregion

        // A global struct showing if PlayGo has been initialized and the SDK version number for the native plugin.
        static internal InitResult m_InitResult;

        internal delegate void SystemUpdate();
        internal static event SystemUpdate OnSystemUpdate;

        internal delegate void SystemShutdown();
        internal static event SystemShutdown OnSystemShutdown;

        /// <summary>
        /// Initialise the Unity PlayGo system
        /// </summary>
        /// <returns>Returns the results of initialization including the SDK version. <see cref="InitResult"/></returns>
        public static InitResult Initialize()
        {
            APIResult result;

            NativeInitResult nativeResult = new NativeInitResult();

            Playgo_PrxInitialize(out nativeResult, out result);

            if (result.RaiseException == true)
                throw new PlayGoException(result);

            MarshalMethods.Initialize();

            m_InitResult.Initialize(nativeResult);

            Start();

            return m_InitResult;
        }

        /// <summary>
        /// Update function. Must be called each frame from the main Unity thread
        /// </summary>
        public static void Update()
        {
            Playgo_PrxUpdate();

            if (OnSystemUpdate != null)
            {
                OnSystemUpdate();
            }
        }

        /// <summary>
        /// Shutdown the Unity PlayGo system
        /// </summary>
        public static void ShutDown()
        {
            if (OnSystemShutdown != null)
            {
                OnSystemShutdown();
            }
            Playgo_PrxShutDown();
        }

        #region DLL Import

        [DllImport(LibraryInfo.LibraryName)]
        private static extern ulong Playgo_PrxConvertScenario(uint scenarioID);

        [DllImport(LibraryInfo.LibraryName)]
        private static extern ulong Playgo_PrxConvertLanguage(int systemLanguage);

        [DllImport(LibraryInfo.LibraryName)]
        private static extern bool PrxSupportsRequestNextChunk();

        [DllImport(LibraryInfo.LibraryName)]
        private static extern int Playgo_PrxGetPlayGoHandle();

        [DllImport("PlayGo_nosubmission")]
        private static extern void PrxEmuRequestNextChunk(int handle, out APIResult result);

        [DllImport("PlayGo_nosubmission")]
        private static extern void PrxEmuSnapshot(int handle, string filePath, out APIResult result);

        #endregion

        // must match enum in PluginPlayGo.h
        enum NativeMethods : UInt32
        {
            Initialise = 0x0200001u,
            Terminate = 0x0200002u,
            Open = 0x0200003u,
            Close = 0x0200004u,
            GetLocus = 0x0200005u,
            Prefetch = 0x0200006u,
            GetEta = 0x0200007u,
            GetToDoList = 0x0200008u,
            GetChunkId = 0x0200009u,
            PrefetchOptionalChunk = 0x020000Au,
            SetToDoList = 0x020000Bu,

            GetInstallChunkId = 0x020000Cu,
            GetInstallSpeed = 0x020000Du,
            SetInstallSpeed = 0x020000Eu,
            GetProgress = 0x020000Fu,
            GetOptionalChunk = 0x0200010u,
            GetSupportedOptionalChunk = 0x0200011u,
        }

        /// <summary>
        /// The maximum possible value of a PlayGo estimated time of arrival.
        /// </summary>
        public const long kEtaMax = 9223372036854775807;    // see SCE_PLAYGO_MAX_ETA_VALUE

        /// <summary>
        /// The maximum allowed value of a PlayGo chunk index.
        /// </summary>
        public const short kMaxChunkIndex = 1000;   // see SCE_PLAYGO_CHUNK_INDEX_MAX

        /// <summary>
        /// The maximum allowed number of scenarios
        /// </summary>
        public const int kMaxScenario = 5;      // see SCE_PLAYGO_MAX_SCENARIO

        /// <summary>
        /// The maximum allowed number of languages
        /// </summary>
        public const int kMaxLanguage = 64;     // see SCE_PLAYGO_MAX_LANGUAGE

        /// <summary>
        /// Bit mask for all languages.
        /// </summary>
        public const ulong kLanguageMaskAll = 0xFFFFFFFFFFFFFFFF;   // see SCE_PLAYGO_LANGUAGE_MASK_ALL

        /// <summary>
        /// Indicates a chunks locus, the location where chunk data exists.
        /// </summary>
        public enum Locus : byte
        {
            /// <summary>
            /// The chunk has not been downloaded.
            /// </summary>
            NotDownloaded = 0,
            /// <summary>
            /// The chunk is available in slow local storage - Blu-ray disc, not used on PS5.
            /// </summary>
            LocalSlow = 2,
            /// <summary>
            /// The chunk is available in fast local storage - SSD
            /// </summary>
            LocalFast = 3
        }

        /// <summary>
        /// Indicates an installation processing speed.
        /// </summary>
        public enum InstallSpeed : int
        {
            /// <summary>
            /// Installation temporarily suspended. If this state continues for 30 seconds it will transition to slow installation mode.
            /// </summary>
            Suspended = 0,
            /// <summary>
            /// Slow installation mode. Game I/O takes priority over installation.
            /// </summary>
            Trickle = 1,
            /// <summary>
            /// Fast installation mode. Installation takes priority over game I/O.
            /// </summary>
            Full = 2
        }

        /// <summary>
        /// Type of PlayGo optional chunk.
        /// The type is used when specifying or obtaining optional chunks with mesthods such as PrefetchOptionalChunk.
        /// </summary>
        public enum OptionalChunkType : int
        {
            /// <summary>
            /// Language
            /// </summary>
            Language = 0,
            /// <summary>
            /// Scenario
            /// </summary>
            Scenario = 1
        }

        /// <summary>
        /// Structure storing information for a PlayGo optional chunk.
        /// This structure is used for setting and obtaining a PlayGo optional chunk. Refer to GetOptionalChunk().
        /// </summary>
        public struct OptionalChunk
        {
            /// <summary>
            /// Construct with a bitmask.
            /// </summary>
            /// <param name="_bitMask"> The bit mask value </param>
            public OptionalChunk(ulong _bitMask)
            {
                languages = scenarios = _bitMask;
            }
            /// <summary>
            /// Bit mask value.
            /// </summary>
            public ulong bitMask { get { return languages | scenarios; } }
            /// <summary>
            /// Language mask.
            /// </summary>
            public ulong languages;
            /// <summary>
            /// Scenario mask, each bit corresponds to the value specified in the 'id' attribute of a 'scenario' XML tag, i.e. b0 = scenario id 1, b1 = scenario id 2, etc...
            /// </summary>
            public ulong scenarios;
        }

        /// <summary>
        /// Structure that represents the chunk installation progress status.
        /// </summary>
        public struct Progress
        {
            /// <summary>
            /// Size of the transferred data in bytes.
            /// </summary>
            public long progressSize;
            /// <summary>
            /// Size of the data to be transferred in bytes.
            /// </summary>
            public long totalSize;
        }

        static WorkerThread workerQueue = new WorkerThread();

        /// <summary>
        /// Converts a scenario number to a scenario mask.
        /// </summary>
        /// <param name="scenarioID">The scenario number to convert.</param>
        /// <returns>Returns a 64 bit mask value.</returns>
        public static ulong ConvertScenario(uint scenarioID)
        {
            //   return PrxConvertScenario(scenarioID);
            return 0;
        }

        /// <summary>
        /// Converts a system language value to a PlayGo language value.
        /// </summary>
        /// <param name="systemLanguage">The system language</param>
        /// <returns>Returns a PlayGo language value.</returns>
        public static ulong ConvertLanguage(int systemLanguage)
        {
            return Playgo_PrxConvertLanguage(systemLanguage);
        }

        /// <summary>
        /// Gets whether or not the currently loaded PlayGo native plugin supports the EmuRequestNextChunk function.
        /// </summary>
        /// <returns>Returns true if EmuRequestNextChunk is supported by the plugin.</returns>
        public static bool SupportsRequestNextChunk()
        {
            return PrxSupportsRequestNextChunk();
        }

        /// <summary>
        /// Get the PlayGo handle.
        /// </summary>
        /// <returns>Returns the handle, or 0 if the PlayGo system has not been opened.</returns>
        public static int GetPlayGoHandle()
        {
#if PLATFORM_PS5 && !UNITY_EDITOR
            return Playgo_PrxGetPlayGoHandle();
#else
            return 0;
#endif
        }

        /// <summary>
        /// Requests the next chunk in the PlayGo emulation file system.
        ///
        /// This function changes the locus of the chunk at the beginning of the PlayGo to-do list to LocalFast (the state where the chunk is in fast local storage).
        /// Use this function during development when you're using the PlayGo emulation file system and you want to control chunk states.
        /// Refer to PlayGo Library Overview - Features to Assist Development of PlayGo Compatible Applications for details about the PlayGo emulation file system.
        /// </summary>
        /// <param name="handle">The PlayGo handle.</param>
        /// <param name="result">Returns the API call result.</param>
        public static void EmuRequestNextChunk(int handle, out APIResult result)
        {
            PrxEmuRequestNextChunk(handle, out result);
        }

        /// <summary>
        /// Exports chunk states to a file
        /// </summary>
        /// <param name="handle">The PlayGo handle.</param>
        /// <param name="filePath">Name of the file to export to.</param>
        /// <param name="result">Returns the API call result.</param>
        public static void EmuSnapshot(int handle, string filePath, out APIResult result)
        {
            PrxEmuSnapshot(handle, filePath, out result);
        }

        struct PlayGoLanguage
        {
            public int id;
            public string languageCode;
            public string languageName;
        }

        static PlayGoLanguage[] m_PlayGoLanguages =
        {
            new PlayGoLanguage { id = 0, languageCode = "ja-JP", languageName = "Japanese" },
            new PlayGoLanguage { id = 1, languageCode = "en-US", languageName = "English (United States)" },
            new PlayGoLanguage { id = 2, languageCode = "fr-FR", languageName = "French (France)" },
            new PlayGoLanguage { id = 3, languageCode = "es-ES", languageName = "Spanish (Spain)" },
            new PlayGoLanguage { id = 4, languageCode = "de-DE", languageName = "German" },
            new PlayGoLanguage { id = 5, languageCode = "it-IT", languageName = "Italian" },
            new PlayGoLanguage { id = 6, languageCode = "nl-NL", languageName = "Dutch" },
            new PlayGoLanguage { id = 7, languageCode = "pt-PT", languageName = "Portuguese (Portugal)" },
            new PlayGoLanguage { id = 8, languageCode = "ru-RU", languageName = "Russian" },
            new PlayGoLanguage { id = 9, languageCode = "ko-KR", languageName = "Korean" },
            new PlayGoLanguage { id = 10, languageCode = "zh-Hant", languageName = "Chinese (traditional)" },
            new PlayGoLanguage { id = 11, languageCode = "zh-Hans", languageName = "Chinese (simplified)" },
            new PlayGoLanguage { id = 12, languageCode = "fi-FI", languageName = "Finnish" },
            new PlayGoLanguage { id = 13, languageCode = "sv-SE", languageName = "Swedish" },
            new PlayGoLanguage { id = 14, languageCode = "da-DK", languageName = "Danish" },
            new PlayGoLanguage { id = 15, languageCode = "no-NO", languageName = "Norwegian" },
            new PlayGoLanguage { id = 16, languageCode = "pl-PL", languageName = "Polish" },
            new PlayGoLanguage { id = 17, languageCode = "pt-BR", languageName = "Portuguese (Brazil)" },
            new PlayGoLanguage { id = 18, languageCode = "en-GB", languageName = "English (United Kingdom)" },
            new PlayGoLanguage { id = 19, languageCode = "tr-TR", languageName = "Turkish" },
            new PlayGoLanguage { id = 20, languageCode = "es-419",languageName =  "Spanish (Latin America)" },
            new PlayGoLanguage { id = 21, languageCode = "ar-AE", languageName = "Arabic" },
            new PlayGoLanguage { id = 22, languageCode = "fr-CA", languageName = "French (Canada)" },
            new PlayGoLanguage { id = 23, languageCode = "cs-CZ", languageName = "Czech" },
            new PlayGoLanguage { id = 24, languageCode = "hu-HU", languageName = "Hungarian" },
            new PlayGoLanguage { id = 25, languageCode = "el-GR", languageName = "Greek" },
            new PlayGoLanguage { id = 26, languageCode = "ro-RO", languageName = "Romanian" },
            new PlayGoLanguage { id = 27, languageCode = "th-TH", languageName = "Thai" },
            new PlayGoLanguage { id = 28, languageCode = "vi-VN", languageName = "Vietnamese" },
            new PlayGoLanguage { id = 29, languageCode = "id-ID", languageName = "Indonesian" },
        };

        /// <summary>
        /// Get play go language codes.
        /// Given a PlayGo language mask build a string listing all of the language codes that correspond to set-bits within the mask.
        /// </summary>
        /// <param name="languageMask">The language bit mask.</param>
        /// <returns>Returns a string containing the language codes.</returns>
        public static string LanguageMaskToString(ulong languageMask)
        {
            string codes = "";
            int count = 0;
            for (int i = 0; i < m_PlayGoLanguages.Length; ++i)
            {
                ulong mask = ConvertLanguage(m_PlayGoLanguages[i].id);
                if ((languageMask & mask) == mask)
                {
                    if (count > 0)
                        codes += ", ";
                    codes += m_PlayGoLanguages[i].languageCode;
                    count++;
                }
            }
            return codes;
        }

        /// <summary>
        /// Get play go scenario IDs.
        /// //
        /// Given a PlayGo scenario mask build a string listing all of the scenario IDs that correspond to set-bits within the mask.
        /// </summary>
        /// <param name="scenarioMask">The scenario bit mask.</param>
        /// <returns>Returns a string listing the scenario IDs represented by the scenario mask.</returns>
        public static string ScenarioMaskToString(ulong scenarioMask)
        {
            string codes = "";
            int count = 0;
            for (uint i = 0; i < kMaxScenario; ++i)
            {
                ulong mask = ConvertScenario(i);
                if ((scenarioMask & mask) == mask)
                {
                    if (count > 0)
                        codes += ", ";
                    codes += i.ToString();
                    count++;
                }
            }
            return codes;
        }

        internal static void Start()
        {
            workerQueue.Start("PlayGo");
        }

        /// <summary>
        /// Schedule an <see cref="AsyncOp"/> by adding it to the internal UniversalDataSystem queue
        /// </summary>
        /// <param name="op">The operation to schedule</param>
        public static void Schedule(AsyncOp op)
        {
            workerQueue.Schedule(op);
        }

        /// <summary>
        /// Initialise the PlayGo system.
        /// </summary>
        public class InitialiseRequest : Request
        {
            protected internal override void Run()
            {
                MarshalMethods.MethodHandle nativeMethod = MarshalMethods.PrepareMethod((UInt32)NativeMethods.Initialise);
                nativeMethod.Call();
                Result = nativeMethod.callResult;
                MarshalMethods.ReleaseHandle(nativeMethod);
            }
        }

        /// <summary>
        /// Terminates the PlayGo system.
        /// </summary>
        public class TerminateRequest : Request
        {
            protected internal override void Run()
            {
                MarshalMethods.MethodHandle nativeMethod = MarshalMethods.PrepareMethod((UInt32)NativeMethods.Terminate);
                nativeMethod.Call();
                Result = nativeMethod.callResult;
                MarshalMethods.ReleaseHandle(nativeMethod);
            }
        }

        /// <summary>
        /// Open the PlayGo system.
        /// </summary>
        public class OpenRequest : Request
        {
            protected internal override void Run()
            {
                MarshalMethods.MethodHandle nativeMethod = MarshalMethods.PrepareMethod((UInt32)NativeMethods.Open);
                nativeMethod.Call();
                Result = nativeMethod.callResult;
                MarshalMethods.ReleaseHandle(nativeMethod);
            }
        }

        /// <summary>
        /// Close the PlayGo system.
        /// </summary>
        public class CloseRequest : Request
        {
            protected internal override void Run()
            {
                MarshalMethods.MethodHandle nativeMethod = MarshalMethods.PrepareMethod((UInt32)NativeMethods.Close);
                nativeMethod.Call();
                Result = nativeMethod.callResult;
                MarshalMethods.ReleaseHandle(nativeMethod);
            }
        }

        /// <summary>
        /// Request a list of PlayGo chunks contained in the package.
        /// </summary>
        public class GetChunkIdRequest : Request
        {
            /// <summary>
            /// List of IDs of chunks contained in the package
            /// </summary>
            public List<UInt16> ChunkIds { get; internal set; }

            protected internal override void Run()
            {
                MarshalMethods.MethodHandle nativeMethod = MarshalMethods.PrepareMethod((UInt32)NativeMethods.GetChunkId);
                nativeMethod.Call();
                Result = nativeMethod.callResult;

                if (Result.apiResult == APIResultTypes.Success)
                {
                    // Read back the results from the native method /// see GetChunkIdImpl()
                    ushort numChunks = nativeMethod.Reader.ReadUInt16();
                    ChunkIds = new List<UInt16>();
                    for (int i = 0; i < numChunks; i++)
                        ChunkIds.Add(nativeMethod.Reader.ReadUInt16());
                }

                MarshalMethods.ReleaseHandle(nativeMethod);
            }
        }

        /// <summary>
        /// Gets a list of chunks installed with the package.
        /// </summary>
        public class GetInstallChunkIdRequest : Request
        {
            /// <summary>
            /// List of IDs of chunks contained in the package
            /// </summary>
            public List<UInt16> ChunkIds { get; internal set; }

            protected internal override void Run()
            {
                MarshalMethods.MethodHandle nativeMethod = MarshalMethods.PrepareMethod((UInt32)NativeMethods.GetInstallChunkId);
                nativeMethod.Call();
                Result = nativeMethod.callResult;

                if (Result.apiResult == APIResultTypes.Success)
                {
                    // Read back the results from the native method /// see GetInstallChunkIdImpl()
                    System.Console.WriteLine($"GetInstallChunkId returned");
                    ushort numChunks = nativeMethod.Reader.ReadUInt16();
                    ChunkIds = new List<UInt16>();
                    for (int i = 0; i < numChunks; i++)
                        ChunkIds.Add(nativeMethod.Reader.ReadUInt16());
                }

                MarshalMethods.ReleaseHandle(nativeMethod);
            }
        }

        /// <summary>
        /// Get the PlayGo installation speed.
        /// </summary>
        public class GetInstallSpeedRequest : Request
        {
            /// <summary>
            /// Returns the install speed when the request completes.
            /// </summary>
            public InstallSpeed installSpeed { get; internal set; }

            protected internal override void Run()
            {
                MarshalMethods.MethodHandle nativeMethod = MarshalMethods.PrepareMethod((UInt32)NativeMethods.GetInstallSpeed);
                nativeMethod.Call();
                Result = nativeMethod.callResult;

                if (Result.apiResult == APIResultTypes.Success)
                {
                    // Read back the results from the native method /// see GetInstallSpeedImpl()
                    System.Console.WriteLine($"GetInstallSpeed returned");
                }

                MarshalMethods.ReleaseHandle(nativeMethod);
            }
        }

        /// <summary>
        /// Set the PlayGo installation speed.
        /// </summary>
        public class SetInstallSpeedRequest : Request
        {
            /// <summary>
            /// The install speed to be set.
            /// </summary>
            public InstallSpeed installSpeed { get; set; }

            protected internal override void Run()
            {
                MarshalMethods.MethodHandle nativeMethod = MarshalMethods.PrepareMethod((UInt32)NativeMethods.SetInstallSpeed);
                nativeMethod.Writer.Write((int)installSpeed);
                nativeMethod.Call();
                Result = nativeMethod.callResult;

                MarshalMethods.ReleaseHandle(nativeMethod);
            }
        }

        /// <summary>
        /// Get the installation progress for a list of chunks.
        /// </summary>
        public class GetProgressRequest : Request
        {
            /// <summary>
            /// List of chunk id's to request progress values for.
            /// </summary>
            public List<UInt16> ChunkIds { get; set; }

            /// <summary>
            /// Total size of the data size and the total size of the transferred size for the specified chunks.
            /// </summary>
            public Progress TotalProgress { get; internal set; }

            protected internal override void Run()
            {
                MarshalMethods.MethodHandle nativeMethod = MarshalMethods.PrepareMethod((UInt32)NativeMethods.GetProgress);

                if (ChunkIds == null)
                {
                    nativeMethod.Writer.Write((UInt32)0);
                }
                else
                {
                    nativeMethod.Writer.Write((UInt32)ChunkIds.Count);
                    for (int i = 0; i < ChunkIds.Count; i++)
                    {
                        nativeMethod.Writer.Write((UInt16)ChunkIds[i]);
                    }
                }

                nativeMethod.Call();
                Result = nativeMethod.callResult;

                if (Result.apiResult == APIResultTypes.Success)
                {
                    // Read back the results from the native method, see GetProgressImpl()
                    Progress progress = new Progress();
                    progress.progressSize = nativeMethod.Reader.ReadInt64();
                    progress.totalSize = nativeMethod.Reader.ReadInt64();
                    TotalProgress = progress;
                }

                MarshalMethods.ReleaseHandle(nativeMethod);
            }
        }

        /// <summary>
        /// Get the current locus for a list of chunks.
        /// </summary>
        public class GetLocusRequest : Request
        {
            /// <summary>
            /// List of loci values matching the request
            /// </summary>
            public List<Locus> Loci { get; internal set; }
            /// <summary>
            /// List of chunk id's to request loci values
            /// </summary>
            public List<UInt16> ChunkIds { get; set; }

            protected internal override void Run()
            {
                MarshalMethods.MethodHandle nativeMethod = MarshalMethods.PrepareMethod((UInt32)NativeMethods.GetLocus);

                if (ChunkIds == null)
                {
                    nativeMethod.Writer.Write((UInt32)0);
                }
                else
                {
                    nativeMethod.Writer.Write((UInt32)ChunkIds.Count);
                    for (int i = 0; i < ChunkIds.Count; i++)
                    {
                        nativeMethod.Writer.Write((UInt16)ChunkIds[i]);
                    }
                }

                nativeMethod.Call();
                Result = nativeMethod.callResult;

                if (Result.apiResult == APIResultTypes.Success)
                {
                    // Read back the results from the native method /// see GetChunkIdImpl()
                    uint numChunks = nativeMethod.Reader.ReadUInt32();
                    Loci = new List<Locus>();
                    for (int i = 0; i < numChunks; i++)
                        Loci.Add((Locus)nativeMethod.Reader.ReadByte());
                }

                MarshalMethods.ReleaseHandle(nativeMethod);
            }
        }

        /// <summary>
        /// Prefetch a list of chunks.
        /// </summary>
        public class PrefetchRequest : Request
        {
            /// <summary>
            /// List of chunk id's to change prefetch value
            /// </summary>
            public List<UInt16> ChunkIds { get; set; }

            /// <summary>
            /// The desired locus to set for the chunks.
            /// </summary>
            public Locus minimumLocus { get; set; }

            protected internal override void Run()
            {
                MarshalMethods.MethodHandle nativeMethod = MarshalMethods.PrepareMethod((UInt32)NativeMethods.Prefetch);

                if (ChunkIds == null)
                {
                    nativeMethod.Writer.Write((UInt32)0);
                }
                else
                {
                    nativeMethod.Writer.Write((UInt32)ChunkIds.Count);
                    for (int i = 0; i < ChunkIds.Count; i++)
                    {
                        nativeMethod.Writer.Write((UInt16)ChunkIds[i]);
                    }
                }
                nativeMethod.Writer.Write((UInt32)minimumLocus);

                nativeMethod.Call();
                Result = nativeMethod.callResult;

                MarshalMethods.ReleaseHandle(nativeMethod);
            }
        }

        /// <summary>
        /// Get the estimated time of arrival for a list of chunks.
        /// </summary>
        public class GetEtaRequest : Request
        {
            /// <summary>
            /// List of loci values matching the request
            /// </summary>
            public List<UInt64> Eta { get; internal set; }
            /// <summary>
            /// List of chunk id's to request loci values
            /// </summary>
            public List<UInt16> ChunkIds { get; set; }

            protected internal override void Run()
            {
                MarshalMethods.MethodHandle nativeMethod = MarshalMethods.PrepareMethod((UInt32)NativeMethods.GetEta);

                if (ChunkIds == null)
                {
                    nativeMethod.Writer.Write((UInt32)0);
                }
                else
                {
                    nativeMethod.Writer.Write((UInt32)ChunkIds.Count);
                    for (int i = 0; i < ChunkIds.Count; i++)
                    {
                        nativeMethod.Writer.Write((UInt16)ChunkIds[i]);
                    }
                }

                nativeMethod.Call();
                Result = nativeMethod.callResult;

                if (Result.apiResult == APIResultTypes.Success)
                {
                    // Read back the results from the native method /// see GetChunkIdImpl()
                    uint numChunks = nativeMethod.Reader.ReadUInt32();
                    Eta = new List<UInt64>();
                    for (int i = 0; i < numChunks; i++)
                        Eta.Add(nativeMethod.Reader.ReadUInt64());
                }

                MarshalMethods.ReleaseHandle(nativeMethod);
            }
        }

        /// <summary>
        /// Structure representing a chunk in the PlayGo to-list.
        /// </summary>
        public struct Todo
        {
            /// <summary>
            /// The chunks ID.
            /// </summary>
            public UInt16 chunkId;
            /// <summary>
            /// The chunks locs.
            /// </summary>
            public Locus locus;

            /// <summary>
            ///  Constructor.
            /// </summary>
            /// <param name="c">Chunk ID</param>
            /// <param name="l">Chunk Locus</param>
            public Todo(UInt16 c, Locus l)
            {
                chunkId = c;
                locus = l;
            }
        }

        /// <summary>
        /// Get the current PlayGo to-do list.
        /// </summary>
        public class GetToDoListRequest : Request
        {
            /// <summary>
            /// List of loci values matching the request
            /// </summary>
            public List<Todo> TodoList { get; internal set; }

            protected internal override void Run()
            {
                MarshalMethods.MethodHandle nativeMethod = MarshalMethods.PrepareMethod((UInt32)NativeMethods.GetToDoList);

                nativeMethod.Call();
                Result = nativeMethod.callResult;

                if (Result.apiResult == APIResultTypes.Success)
                {
                    // Read back the results from the native method /// see GetChunkIdImpl()
                    uint numChunks = nativeMethod.Reader.ReadUInt32();
                    TodoList = new List<Todo>();
                    for (int i = 0; i < numChunks; i++)
                    {
                        UInt16 chunkId = nativeMethod.Reader.ReadUInt16();
                        Locus locus = (Locus)nativeMethod.Reader.ReadByte();
                        TodoList.Add(new Todo(chunkId, locus));
                    }
                }

                MarshalMethods.ReleaseHandle(nativeMethod);
            }
        }

        /// <summary>
        /// Set the PlayGo to-do list. Can be used to change the order of chunks in the current to-do list.
        /// </summary>
        public class SetToDoListRequest : Request
        {
            /// <summary>
            /// List of loci values matching the request
            /// </summary>
            public List<Todo> TodoList { get; set; }

            protected internal override void Run()
            {
                MarshalMethods.MethodHandle nativeMethod = MarshalMethods.PrepareMethod((UInt32)NativeMethods.SetToDoList);

                if (TodoList == null)
                {
                    nativeMethod.Writer.Write((UInt32)0);
                }
                else
                {
                    nativeMethod.Writer.Write((UInt32)TodoList.Count);
                    for (int i = 0; i < TodoList.Count; i++)
                    {
                        nativeMethod.Writer.Write((UInt16)TodoList[i].chunkId);
                        nativeMethod.Writer.Write((Byte)TodoList[i].locus);
                    }
                }

                nativeMethod.Call();
                Result = nativeMethod.callResult;



                MarshalMethods.ReleaseHandle(nativeMethod);
            }
        }

        /// <summary>
        /// Get language or scenario masks for available optional chunks.
        /// </summary>
        public class GetOptionalChunkRequest : Request
        {
            /// <summary>
            /// The type of optional chunk to get.
            /// </summary>
            public OptionalChunkType type { get; set; }
            /// <summary>
            /// When the request completes, contains the optional chunk language mask if the requested type was OptionalChunkType.Language
            /// </summary>
            public ulong languages { get; private set; }
            /// <summary>
            /// When the request completes, contains the optional chunk scenario mask if the requested type was OptionalChunkType.Scenario
            /// </summary>
            public ulong scenarios { get; private set; }

            protected internal override void Run()
            {
                MarshalMethods.MethodHandle nativeMethod = MarshalMethods.PrepareMethod((UInt32)NativeMethods.GetOptionalChunk);

                nativeMethod.Writer.Write((UInt32)type);

                nativeMethod.Call();
                Result = nativeMethod.callResult;
                languages = nativeMethod.Reader.ReadUInt64();
                scenarios = nativeMethod.Reader.ReadUInt64();

                MarshalMethods.ReleaseHandle(nativeMethod);
            }
        }

        /// <summary>
        /// Get language or scenario masks for supported optional chunks.
        /// </summary>
        public class GetSupportedOptionalChunkRequest : Request
        {
            /// <summary>
            /// The type of optional chunk to get.
            /// </summary>
            public OptionalChunkType type { get; set; }
            /// <summary>
            /// When the request completes, contains the optional chunk language mask if the requested type was OptionalChunkType.Language
            /// </summary>
            public ulong languages { get; private set; }
            /// <summary>
            /// When the request completes, contains the optional chunk scenario mask if the requested type was OptionalChunkType.Scenario
            /// </summary>
            public ulong scenarios { get; private set; }

            protected internal override void Run()
            {
                MarshalMethods.MethodHandle nativeMethod = MarshalMethods.PrepareMethod((UInt32)NativeMethods.GetSupportedOptionalChunk);

                nativeMethod.Writer.Write((UInt32)type);

                nativeMethod.Call();
                Result = nativeMethod.callResult;
                languages = nativeMethod.Reader.ReadUInt64();
                scenarios = nativeMethod.Reader.ReadUInt64();

                MarshalMethods.ReleaseHandle(nativeMethod);
            }
        }

        /// <summary>
        /// Prefetch optional chunks.
        /// </summary>
        public class PrefetchOptionalChunkRequest : Request
        {
            /// <summary>
            /// The type of optional chunk to prefetch.
            /// </summary>
            public OptionalChunkType type { get; set; }
            /// <summary>
            /// The optional chunk language mask if the requested type was OptionalChunkType.Language
            /// </summary>
            public ulong languages { get; set; }
            /// <summary>
            /// The optional chunk scenario mask if the requested type was OptionalChunkType.Scenario
            /// </summary>
            public ulong scenarios { get; set; }

            protected internal override void Run()
            {
                MarshalMethods.MethodHandle nativeMethod = MarshalMethods.PrepareMethod((UInt32)NativeMethods.PrefetchOptionalChunk);

                nativeMethod.Writer.Write((UInt32)type);
                nativeMethod.Writer.Write(languages);
                nativeMethod.Writer.Write(scenarios);

                nativeMethod.Call();
                Result = nativeMethod.callResult;

                MarshalMethods.ReleaseHandle(nativeMethod);
            }
        }
    }
}
