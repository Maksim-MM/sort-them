
using System.Runtime.InteropServices;
using System.IO;

namespace Unity.PlayGo.PS5
{
    /// <summary>
    /// Class implmenting methods for displaying and working with the PlayGo system dialog.
    /// </summary>
    public class Dialog
    {
        /// <summary>
        /// The status of the PlayGo dialog.
        /// </summary>
        public enum Status : int
        {
            /// <summary>
            /// Dialog is not running
            /// </summary>
            None = 0,
            /// <summary>
            /// The dialog is initialized.
            /// </summary>
            Initialized = 1,
            /// <summary>
            /// The dialog is being displayed.
            /// </summary>
            Running = 2,
            /// <summary>
            /// The dialog has closed.
            /// </summary>
            Finished = 3
        }

        /// <summary>
        /// The mode to use when displaying the PlayGo dialog.
        /// </summary>
        public enum Mode : int
        {
            /// <summary>
            /// Displaying progress bar.
            /// </summary>
            ProgressBar = 1,
            //DiscChange = 2,   // Displaying disc change guide, keep this one commented out as a reminder for now, it is in the SDK but it looks like it might be deprecated on PS5.
            /// <summary>
            ///  Displaying additional installation.
            /// </summary>
            RequestInstall = 3,
        }

        /// <summary>
        /// The type of progress bar to display.
        /// </summary>
        public enum ProgressBarType : int
        {
            /// <summary>
            /// Display progress bar about single chunk list.
            /// </summary>
            SingleChunkList = 0,
            /// <summary>
            /// Display progress bar about enumerated chunk list.
            /// </summary>
            EnumeratedChunkList = 1,
        }

        // Displaying disc change guide, keep this one commented out as a reminder for now, it is in the SDK but it looks like it might be deprecated on PS5.
        //public enum DiscChangeType : int
        //{
        //    LanguageMask = 0,    // Disc change by specifying language mask.
        //}

        /// <summary>
        /// PlayGo dialog result values.
        /// </summary>
        public enum Result : int
        {
            /// <summary>
            /// Closed by user operation or closed by DialogClose()
            /// </summary>
            Ok = 0,
            /// <summary>
            /// Dialog was closed automatically given the preparation completion of the specified chunks
            /// </summary>
            AutoClosed = 3,
            /// <summary>
            /// Request for additional installation was successful
            /// </summary>
            AdditionalInstallSucceeded = 4,
            /// <summary>
            /// // SCE_COMMON_DIALOG_ERROR_PARAM_INVALID - Parameter content specified to scePlayGoDialogOpen() is invalid.
            /// </summary>
            OpenParamInvalid = -2135425014,
        };

        /// <summary>
        /// Structure containing PlayGo dialog results.
        /// </summary>
        public struct DialogResult
        {
            /// <summary>
            /// The mode the dialog was in.
            /// </summary>
            public Mode mode;
            /// <summary>
            /// The dialog result value.
            /// </summary>
            public int resultValue;
            /// <summary>
            /// The dialog result value.
            /// </summary>
            public Result result { get { return (Result)resultValue; } }
        }

        /// <summary>
        /// Structure defining a PlayGo progress dialog item.
        /// </summary>
        public struct ProgressDialogItem
        {
            /// <summary>
            /// Array of chunk IDs that the bar is showing progress for.
            /// </summary>
            public ushort[] chunkIDs;
            /// <summary>
            /// A string to display next to the progress bar.
            /// </summary>
            public string label;
        }

        #region DLL Import

        [DllImport(LibraryInfo.LibraryName)]
        private static extern void PrxOpenProgressDialog(int handle, byte[] sourceData, int sourceSize, out APIResult apiResult);

        [DllImport(LibraryInfo.LibraryName)]
        private static extern void PrxOpenRequestInstallDialog(int handle, Main.OptionalChunkType optionalChunkType, ulong bitmask, out APIResult apiResult);

        [DllImport(LibraryInfo.LibraryName)]
        private static extern Status PrxUpdateStatus();

        [DllImport(LibraryInfo.LibraryName)]
        private static extern DialogResult PrxGetResult(out APIResult apiResult);

        [DllImport(LibraryInfo.LibraryName)]
        private static extern void PrxCloseDialog(out APIResult apiResult);

        #endregion

        class WriteBuffer
        {
            public byte[] buffer;
            public MemoryStream writeStream;
            public BinaryWriter writer;

            public WriteBuffer(int bufferSize)
            {
                buffer = new byte[bufferSize];
                writeStream = new MemoryStream(buffer);
                writer = new BinaryWriter(writeStream);
            }
        }

        class ReadBuffer
        {
            public byte[] buffer;
            public MemoryStream readStream;
            public BinaryReader reader;

            public ReadBuffer(int bufferSize)
            {
                buffer = new byte[bufferSize];
                readStream = new MemoryStream(buffer);
                reader = new BinaryReader(readStream);
            }
        }

        /// <summary>
        /// Open the PlayGo progress dialog.
        /// </summary>
        /// <param name="handle">The PlayGo handle.</param>
        /// <param name="items">An array of progress items to populate the dialog with.</param>
        /// <param name="apiResult">Returns the API call result.</param>
        public static void OpenProgressDialog(int handle, ProgressDialogItem[] items, out APIResult apiResult)
        {
            // Calc buffer size.
            int bufferSize = Marshal.SizeOf<int>();
            for (int i = 0; i < items.Length; i++)
            {
                int size0 = Marshal.SizeOf<int>() + Marshal.SizeOf<ushort>() * items[i].chunkIDs.Length;
                int size1 = Marshal.SizeOf<int>() + Marshal.SizeOf<char>() * items[i].label.Length;
                bufferSize += size0 + size1;
            }

            // Serialize into buffer.
            WriteBuffer marshalItems = new WriteBuffer(bufferSize);
            marshalItems.writer.Write(items.Length);
            for (int i = 0; i < items.Length; i++)
            {
                marshalItems.writer.Write(items[i].chunkIDs.Length);
                for (int j = 0; j < items[i].chunkIDs.Length; j++)
                {
                    marshalItems.writer.Write(items[i].chunkIDs[j]);
                }
                marshalItems.writer.Write(items[i].label.Length);
                marshalItems.writer.Write(items[i].label.ToCharArray());
            }
            PrxOpenProgressDialog(handle, marshalItems.buffer, marshalItems.buffer.Length, out apiResult);
        }

        /// <summary>
        /// Open a dialog to request installation of optional chunks.
        /// </summary>
        /// <param name="handle">The PlayGo handle.</param>
        /// <param name="optionalChunkType">The type of optional chunks to request.</param>
        /// <param name="optionalChunk">The optional chunk definition.</param>
        /// <param name="apiResult">Returns the API call result.</param>
        public static void OpenRequestInstallDialog(int handle, Main.OptionalChunkType optionalChunkType, Main.OptionalChunk optionalChunk, out APIResult apiResult)
        {
            PrxOpenRequestInstallDialog(handle, optionalChunkType, optionalChunk.bitMask, out apiResult);
        }

        /// <summary>
        /// Update and get the dialog status.
        /// </summary>
        /// <returns>Returns the current status of the PlayGo dialog.</returns>
        public static Status UpdateStatus()
        {
            Status status = PrxUpdateStatus();
            return status;
        }

        /// <summary>
        /// Get the dialog result.
        /// </summary>
        /// <param name="apiResult">Returns the API call result.</param>
        /// <returns>Returns the dialog result value.</returns>
        public static DialogResult GetResult(out APIResult apiResult)
        {
            DialogResult result = PrxGetResult(out apiResult);
            return result;
        }

        /// <summary>
        /// Close the PlayGo dialog if it is open.
        /// </summary>
        /// <param name="apiResult">Returns the API call result.</param>
        public static void CloseDialog(out APIResult apiResult)
        {
            PrxCloseDialog(out apiResult);
        }
    }
}
