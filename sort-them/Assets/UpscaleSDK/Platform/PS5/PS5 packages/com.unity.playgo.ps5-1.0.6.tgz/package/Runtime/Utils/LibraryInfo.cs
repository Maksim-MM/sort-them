
namespace Unity.PlayGo.PS5
{
    internal static class LibraryInfo
    {
        internal const string LibraryName = "PlayGo";
        internal static string LibraryNameWithExtension => $"{LibraryName}.prx";
    }
}
