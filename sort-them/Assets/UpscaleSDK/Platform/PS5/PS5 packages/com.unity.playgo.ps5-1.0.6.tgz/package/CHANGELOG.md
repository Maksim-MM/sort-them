# Changelog
All notable changes to the package will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

Due to package verification, the latest version below is the unpublished version and the date is meaningless, however, it has to be formatted properly to pass verification tests.

## [1.0.6] - 2025-10-21

### Changed
- Signature files have been updated
- Updated XML documentation for all public APIs.
- Updated to support SDK 12

### Fixed
- Fixed a bug that caused the native PRX to fail to recompile when upgrading to a new package .tgz.

## [1.0.5] - 2024-08-22

### Fixed
- Fixed a linker error that could occour on recent Unity versions

## [1.0.4] - 2024-04-16

### Fixed
- Fixed a null reference exception that could occur when creating a build for Windows IL2CPP in 2021.3

## [1.0.3] - 2024-02-26

### Fixed
- Fixed a infinite build loop that could occur when an error was thrown during serialization (e.g shader compilation)

## [1.0.2] - 2024-01-10

### Fixed
   - Fixed an issue where the pacakge would invalidate the PackageCache when building and the package was added from a UMP Server
   - Fixed an issue where absoulte paths in the generated cpp would dirty source control when no cotents of the file has changed
   - Fixed an issue where compiling for PS5 when PS5 was not the selected platform would result in the package PRX (or cpp replacement) not being generated

### Changed
   - Instead of a pre-processed cpp source file generated in the package folder, the package now generates a prx in the Library/SoruceGeneratedPlugins folder which is added to the build

## [1.0.1] - 2023-10-18

### Fixed
   - Stop editor build script executing when an non-PlayStation platform is being built
   - Stopped multiple definitions of module_start() from being created

## [1.0.0] - 2023-09-04
   - New package format.

## [0.0.10] - 2023-04-06

### Added
   - Added support for SDK 7.0


## [0.0.9] - 2023-03-22

### Fixed
   - Fixed SCE_COMMON_DIALOG_ERROR_BUSY error by correcting the lifespan of the PlayGo dialogs (IN-11851)

## [0.0.8] - 2022-10-19

### Added
   - Added support for SDK 6.0
   - Added support for SDK 5.0

## [0.0.7] - 2021-11-23

### Added
   - Added support for SDK 4.0

## [0.0.6] - 2021-11-10

### Added
   Added the following functions to the PlayGo class...

      PlayGo.PS5.Main.GetInstallChunkIdRequest
      PlayGo.PS5.Main.GetInstallSpeedRequest
      PlayGo.PS5.Main.SetInstallSpeedRequest
      PlayGo.PS5.Main.GetProgressRequest
      PlayGo.PS5.Main.GetOptionalChunkRequest
      PlayGo.PS5.Main.GetSupportedOptionalChunkRequest
      PlayGo.PS5.Main.EmuRequestNextChunkRequest

   Added a new PlayGo.PS5.Dialog class for working with the system PlayGo dialogs. These functions give access to the system dialogs for requesting installation of optional scenarios and languages and displaying chunk installation progress.

      PlayGo.PS5.Dialog.OpenProgressDialog
      PlayGo.PS5.Dialog.OpenRequestInstallDialog
      PlayGo.PS5.Dialog.CloseDialog
      PlayGo.PS5.Dialog.UpdateStatus
      PlayGo.PS5.Dialog.GetResult

   Added sample code to demonstrate adding a PlayGo emulation file into a PC hosted build during build processing, uses the UnityEditor.PS5.IPostProcessPS5PrepareStagingArea interface which is available in Unity 2022.1 and later versions.

   Added sample code to demonstrate adding chunk and scenario information into a GP5 project file using a PlayGo emulation file as a template when building an installable package, uses the UnityEditor.PS5.IPostProcessPS5CreateGP5Project interface which is available in Unity 2022.1 and later versions.

## [0.0.5-preview] - 2021-07-13

### Added
   - Added support for SDK 3.0

## [0.0.4-preview] - 2021-05-12

### Changes

- Added correct native plugins for supported sdk's

## [0.0.3-preview] - 2021-04-09

### Changes

- Rebuilt all meta files again

## [0.0.2-preview] - 2021-01-10
 
### Changed

- Recreated duplicated .meta files

## [0.0.1-preview] - 2020-03-01

### Added

- Initial Version
