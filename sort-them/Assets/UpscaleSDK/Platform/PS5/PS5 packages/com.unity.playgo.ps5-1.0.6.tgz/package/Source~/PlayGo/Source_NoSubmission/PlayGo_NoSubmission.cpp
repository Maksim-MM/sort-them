#include <stdio.h>
#include "..\Source\Plugin.h"
#include <playgo.h>

#pragma comment(lib, "libScePlayGo_nosubmission_stub_weak.a")

namespace playgo_nosubmission
{
    DO_EXPORT(void, PrxEmuRequestNextChunk) (int handle, SceApi::APIResult* result)
    {
        int32_t ret = scePlayGoRequestNextChunk(handle, nullptr);
        if (ret < 0)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        SUCCESS_RESULT(result);
    }

    DO_EXPORT(void, PrxEmuSnapshot) (int handle, char* filePath, SceApi::APIResult* result)
    {
        int32_t ret = scePlayGoSnapshot(handle, filePath);
        if (ret < 0)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        SUCCESS_RESULT(result);
    }
}
