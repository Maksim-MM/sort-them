# PS5 PlayGo Package 

The PlayGo package implements an API to provide access to the PS5 PlayGo features.

To get started, see the [Installation](Installation.md) section.

To try out the PlayGo Sample app see the [Sample](Sample.md) instructions
