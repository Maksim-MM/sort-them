using System;
using System.IO;
using NUnit.Framework;
using Unity.PSN.PS5;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;
using PlayerSettings = UnityEditor.PlayerSettings;

public abstract class BuildTests
{
    string m_TempBuildPath;
    string m_TempScenePath = "Assets/TestScene.unity";
    protected BuildReport m_Report;

    [OneTimeSetUp]
    protected virtual void CreateBuild()
    {
        (BuildTargetGroup group, BuildTarget target) build = GetBuildTarget();
        EditorUserBuildSettings.SwitchActiveBuildTarget(build.group, build.target);

        //Always create a clean build
        BuildOptions buildOptionsWithClean = GetBuildOptions() | BuildOptions.CleanBuildCache;

        var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene);
        EditorSceneManager.SaveScene(scene, m_TempScenePath);
        string[] scenes = { scene.path };

 m_TempBuildPath = Path.GetFullPath($"{Path.GetTempPath()}/TestGeneratedBuild");
        m_Report = BuildPipeline.BuildPlayer(scenes,
            Path.Combine(m_TempBuildPath, $"TestBuild_{DateTime.Now.ToFileTime()}"), build.target, buildOptionsWithClean);
    }

    [OneTimeTearDown]
    public void CleanupAfterBuild()
    {
        //Clean up temp scene
        AssetDatabase.DeleteAsset(m_TempScenePath);
        Directory.Delete(m_TempBuildPath, true);
        m_Report = null;
    }

    [Test]
    public void NoErrorsCompilingProject()
    {
        string errorString = string.Empty;
        #if UNITY_2023_1_OR_NEWER
        errorString = m_Report.SummarizeErrors();
        #endif

        Assert.That(m_Report.summary.result, Is.EqualTo(BuildResult.Succeeded),
            $"Failed to build project\n{errorString}");
    }

    protected abstract BuildOptions GetBuildOptions();
    protected abstract (BuildTargetGroup, BuildTarget) GetBuildTarget();
}


public abstract class BuildTestExpectedPlugin : BuildTests
{
    [Test]
    public void ContainsGeneratedPlugin()
    {
        string expectedPluginPath = Path.Combine(m_Report.summary.outputPath, "Build", "Media", "Plugins", LibraryInfo.LibraryNameWithExtension);
        Assert.That(File.Exists(expectedPluginPath), $"No PRX at path {expectedPluginPath}");
    }
}
