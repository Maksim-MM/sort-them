#pragma once
#include <np.h>


namespace psn
{

/// @brief  RAII wrapper around Np Request creation and deletion.
class ScopedNpRequest
{
public:
    /// @brief The request id.  The value returned from sceNpCreateRequest.  This will be a positive integer on success.
    const int id;

    ScopedNpRequest() :
        id (sceNpCreateRequest())
    {}

    ScopedNpRequest(const ScopedNpRequest&) = delete;

    /// @brief Was the request created successfully?
    /// @return `true` if sceNpCreateRequest succeeded and `id` is a positive integer.
    [[nodiscard]]
    bool ok() const noexcept {return id > 0;}

    ~ScopedNpRequest()
    {
        if (!ok())
            return;
        sceNpDeleteRequest(id);
    }
};

}