# Install the PlayStation Network package

The PS5 is a closed platform. For this reason, you must download the PlayStation Network package directly from the DevNet forum, instead of from the Package Manager. 

To install the package and add it to your Unity project, do the following:

1. Go to the [PlayStation 5 Package Downloads](https://discussions.unity.com/t/playstation-5-package-downloads/1568720) Unity Discussions page.
2. Select and download the latest PS5 Share Library package tarball (.tgz).
3. In Unity, open the Package Manager window (**Window** > **Package Manager**).
4. Select the **Add** (**+**) button.
5. Select **Add Package from Tarball**.
6. In the “dialog” box, find the PS5 Share Library package .tgz file and select **OK**.