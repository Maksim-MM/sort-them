#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <list>

#include "../Includes/PluginCommonIncludes.h"
#include "SimpleLock.h"
#include "MessagePipe.h"

PRX_EXPORT bool PrxShareHasMessage()
{
	return Share::Messages::HasMessage();
}

PRX_EXPORT bool PrxShareGetFirstMessage(Share::Messages::PluginMessage* result)
{
	return Share::Messages::GetFirstMessage(result);
}

PRX_EXPORT bool PrxShareRemoveFirstMessage()
{
	return Share::Messages::RemoveFirstMessage();
}

namespace Share
{
	namespace Messages
	{
		std::list<PluginMessage*> messages;
		SimpleLock lockMessages;

		void AddLogMessage(int type, const char* format, va_list alist)
		{
			char buffer[256];

			vsnprintf (buffer,256,format, alist);
			perror (buffer);

			PluginMessage* msg = new PluginMessage();
			msg->type = type;
			msg->SetDataFromString(buffer);
			AddMessage(msg);
		}

		void Log(const char* format, ...)
		{
			char buffer[1024];
			va_list args;
			va_start (args, format);
			vsnprintf (buffer, 1024, format, args);
			va_end (args);

			PluginMessage* msg = new PluginMessage();
			msg->type = kShare_Log;
			msg->SetDataFromString(buffer);
			AddMessage(msg);
			UNITY_TRACE("%s",buffer);
		}

		void LogWarning(const char* format, ...)
		{
			char buffer[1024];
			va_list args;
			va_start (args, format);
			vsnprintf (buffer, 1024, format, args);
			va_end (args);

			PluginMessage* msg = new PluginMessage();
			msg->type = kShare_LogWarning;
			msg->SetDataFromString(buffer);
			AddMessage(msg);
			UNITY_TRACE("WARNING: %s\n", buffer);
		}

		void LogError(const char* format, ...)
		{
			char buffer[1024];
			va_list args;
			va_start (args, format);
			vsnprintf (buffer, 1024, format, args);
			va_end (args);

			PluginMessage* msg = new PluginMessage();
			msg->type = kShare_LogError;
			msg->SetDataFromString(buffer);
			AddMessage(msg);
			UNITY_TRACE("ERROR: %s\n", buffer);
		}

		void AddMessage(MessageType msgType)
		{
			PluginMessage* msg = new Share::Messages::PluginMessage();
			msg->type = msgType;
			Share::Messages::AddMessage(msg);
		}
	
		void AddMessage(PluginMessage* msg)
		{
			SimpleLock::AutoLock lock(lockMessages);
			messages.push_back(msg);
		}

		bool HasMessage()
		{
			SimpleLock::AutoLock lock(lockMessages);
			return !messages.empty();
		}

		bool GetFirstMessage(PluginMessage* msg)
		{
			SimpleLock::AutoLock lock(lockMessages);
			if(!messages.empty())
			{
				*msg = *messages.front();
				return true;
			}

			return false;
		}

		bool RemoveFirstMessage()
		{
			SimpleLock::AutoLock lock(lockMessages);
			if(!messages.empty())
			{
				delete messages.front();
				messages.pop_front();
				return true;
			}

			return false;
		}

	}
} // namespace Share
