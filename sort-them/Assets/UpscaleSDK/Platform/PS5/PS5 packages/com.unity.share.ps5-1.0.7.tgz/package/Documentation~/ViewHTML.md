
# Accessing PS5 package documentation

All Playstation 5 (PS5) documentation, including PS5 package documentation, is under non-disclosure agreements (NDAs), so you can’t view the documentation in the same way as other Unity documentation. For this reason, each package provides HTML documentation locally, in the `HTMLDocs~` folder. To view the HTML files, you must run a local web server.

## Prerequisites

To view PS5 package documentation, you must have:

*   The package and package documentation locally on your machine. 
*   Python 3 installed. 

## Viewing PS5 package documentation

To run a local server and view the PS5 package documentation: 

1. In the location of your Unity project folder, open a command prompt.
2. To run a local server on your machine, in the command prompt, run `python -m http.server`.  You see an output similar to this:
`Serving HTTP on :: port 8000 (http://[::]:8000/) …`
3. Open a web browser. 
4. Add the port number to the end of the ``http://localhost:`` URL. For example: `http://localhost:8000/` 
</code>This shows a directory listing of the folders in the drive where you are running the web server. 
5. Use the directory listing to go to the package documentation you want to view, then go to the <code>HTLMDocs~</code> folder and open the HTML documentation in the browser.

