
# Links to Sony documentation

For more information about how to work with the share system, see the following documentation on the PlayStation® Developer network:

| Feature | Link |
| ------- | ---- |
| Main Page | [Share Library Overview](https://game.develop.playstation.net/resources/documents/SDK/latest/Share-Overview/__toc.html) |
| Initialization | [Initialization and Termination](https://game.develop.playstation.net/resources/documents/SDK/latest/Share-Reference/0001.html) |
| Content | [Creating Content](https://game.develop.playstation.net/resources/documents/SDK/latest/Share-Reference/0003.html) |
| Dialog | [Starting the Share Feature](https://game.develop.playstation.net/resources/documents/SDK/latest/Share-Reference/0019.html) |
| Settings | [Setting Tap Points for Share-Related Features](https://game.develop.playstation.net/resources/documents/SDK/latest/Share-Reference/0020.html) |
|| [Setting Preset Information](https://game.develop.playstation.net/resources/documents/SDK/latest/Share-Reference/0020.html) |
|| [Permitting/Prohibiting Share-Related Features](https://game.develop.playstation.net/resources/documents/SDK/latest/Share-Reference/0030.html) |
| Status | [Obtaining the States of Share-Related Features](https://game.develop.playstation.net/resources/documents/SDK/latest/Share-Reference/0025.html) |
