#include "Main.h"
#include "MessagePipe.h"

#include <vector>
#include <stdio.h>
#include <sdk_version.h>
#include <libsysmodule.h>

#pragma comment(lib,"libSceShare_stub_weak.a")

namespace Share
{
    // https://game.develop.playstation.net/resources/documents/SDK/latest/Share-Overview/0002.html#__document_toc_00000006

    PRX_EXPORT void PrxShareInitialize(InitResult* initResult, APIResult* result)
    {
        Main::Initialize(*initResult, result);
    }

    PRX_EXPORT void PrxShareTerminate(APIResult* result)
    {
        Main::Terminate(result);
    }

    PRX_EXPORT void PrxShareFeaturePermit(APIResult* result, uint32_t featureFlags)
    {
        Main::FeaturePermit(result, (SceShareFeatureFlag)featureFlags);
    }

    PRX_EXPORT void PrxShareFeatureProhibit(APIResult* result, uint32_t featureFlags)
    {
        Main::FeatureProhibit(result, (SceShareFeatureFlag)featureFlags);
    }

    PRX_EXPORT int32_t PrxShareCaptureScreenshot(APIResult* result, int32_t format, int32_t tapPoint)
    {
        return Main::CaptureScreenshot(result, format, tapPoint);
    }

    PRX_EXPORT uint64_t PrxShareGetRtcCurrentTick(APIResult* result)
    {
        return Main::GetRtcCurrentTick(result);
    }

    PRX_EXPORT int32_t PrxShareCaptureVideoClipRelative(APIResult* result, int32_t startTime, int32_t endTime)
    {
        return Main::CaptureVideoClipRelative(result, startTime, endTime);
    }

    PRX_EXPORT int32_t PrxShareCaptureVideoClipAbsolute(APIResult* result, uint64_t startTime, uint64_t endTime)
    {
        return Main::CaptureVideoClipAbsolute(result, startTime, endTime);
    }

    PRX_EXPORT void PrxShareOpenMenuForContent(APIResult* result, int64_t contentId)
    {
        Main::OpenContentMenuForContent(result, (SceShareContentId)contentId);
    }

    PRX_EXPORT void PrxShareGetCurrentStatus(APIResult* result, uint32_t featureFlag, CurrentStatus* status)
    {
        Main::GetCurrentStatus(result, featureFlag, status);
    }

    PRX_EXPORT void PrxShareSetContentParam(APIResult* result, const char* contentParam)
    {
        Main::SetContentParam(result, contentParam);
    }

    PRX_EXPORT void PrxShareSetCaptureSource(APIResult* result, SceShareFeatureFlag featureFlags, TapPoints tapPoints)
    {
        Main::SetCaptureSource(result, featureFlags, &tapPoints);
    }

    PRX_EXPORT void PrxShareSetScreenshotOverlayImage(APIResult* result, const char* filePath, int32_t marginX, int32_t marginY, int32_t origin)
    {
        Main::SetScreenshotOverlayImage(result, filePath, marginX, marginY, (SceShareScreenshotOrigin)origin);
    }

    int32_t NotSupportedError(APIResult* result)
    {
        int32_t err = SCE_SHARE_LIBRARY_ERROR_NOT_SUPPORTED;
        SCE_ERROR_RESULT(result, err);
        return err;
    }

#if SCE_PROSPERO_SDK_VERSION >= 0x04000031u
    PRX_EXPORT int32_t PrxShareCaptureScreenshotExtended(APIResult* result, int32_t format, int32_t tapPoint, const char* metadata)
    {
        return Main::CaptureScreenshotExtended(result, format, tapPoint, metadata);
    }

    PRX_EXPORT int32_t PrxShareCaptureVideoClipRelativeExtended(APIResult* result, int32_t startTime, int32_t endTime, const char* metadata)
    {
        return Main::CaptureVideoClipRelativeExtended(result, startTime, endTime, metadata);
    }

    PRX_EXPORT int32_t PrxShareCaptureVideoClipAbsoluteExtended(APIResult* result, uint64_t startTime, uint64_t endTime, const char* metadata)
    {
        return Main::CaptureVideoClipAbsoluteExtended(result, startTime, endTime, metadata);
    }

    PRX_EXPORT void PrxSetContentParamForApplicationTitle(APIResult* result, const char* applicationTitle)
    {
        Main::SetContentParamForApplicationTitle(result, applicationTitle);
    }

    PRX_EXPORT SceShareFeatureFlag PrxShareGetRunningStatus(APIResult* result)
    {
        return Main::GetRunningStatus(result);
    }
#else
    PRX_EXPORT int32_t PrxShareCaptureScreenshotExtended(APIResult* result, int32_t format, int32_t tapPoint, const char* metadata)
    {
        return NotSupportedError(result);
    }

    PRX_EXPORT int32_t PrxShareCaptureVideoClipRelativeExtended(APIResult* result, int32_t startTime, int32_t endTime, const char* metadata)
    {
        return NotSupportedError(result);
    }

    PRX_EXPORT int32_t PrxShareCaptureVideoClipAbsoluteExtended(APIResult* result, uint64_t startTime, uint64_t endTime, const char* metadata)
    {
        return NotSupportedError(result);
    }

    PRX_EXPORT void PrxSetContentParamForApplicationTitle(APIResult* result, const char* applicationTitle)
    {
        NotSupportedError(result);
    }

    PRX_EXPORT SceShareFeatureFlag PrxShareGetRunningStatus(APIResult* result)
    {
        NotSupportedError(result);
        return 0;
    }
#endif

    bool Main::s_Initialised = false;

    // Callback function called when content has been created
    static void OnShareContentEvent(SceShareRequestId reqId, SceShareContentEventType type, int32_t errorCode, SceShareContentId contentId, int32_t duration, void *userData)
    {
        Messages::PluginMessage* msg = new Messages::PluginMessage();
        msg->type = Messages::kShare_GotRequestResult;
        ContentEventData data = {reqId, type, errorCode, contentId, duration};
        msg->SetData(&data, sizeof(data));
        Messages::AddMessage(msg);
    }

    void Main::Initialize(InitResult& initResult, APIResult* result)
    {
        if (s_Initialised)
        {
            ERROR_RESULT(result, "Share Plugin already initialised"); // Already initialised
            return;
        }

        int32_t ret = sceSysmoduleLoadModule(SCE_SYSMODULE_SHARE);
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        ret = sceShareInitialize(SCE_SHARE_HEAP_SIZE, SCE_KERNEL_PRIO_FIFO_DEFAULT, SCE_KERNEL_CPUMASK_13CPU);
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        ret = sceShareRegisterContentEventCallback(OnShareContentEvent, nullptr);
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        s_Initialised = true;

        initResult.initialized = true;
        initResult.sceSDKVersion = SCE_PROSPERO_SDK_VERSION;

        SUCCESS_RESULT(result);
    }

    void Main::Terminate(APIResult* result)
    {
        int32_t ret = sceShareTerminate();
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        ret = sceSysmoduleUnloadModule(SCE_SYSMODULE_SHARE);

        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        s_Initialised = false;

        SUCCESS_RESULT(result);
    }

    void Main::FeaturePermit(APIResult* result, SceShareFeatureFlag featureFlags)
    {
        int32_t ret = sceShareFeaturePermit(featureFlags);
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
        }
    }

    void Main::FeatureProhibit(APIResult* result, SceShareFeatureFlag featureFlags)
    {
        int32_t ret = sceShareFeatureProhibit(featureFlags);
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
        }
    }

    int32_t Main::CaptureScreenshot(APIResult* result, SceShareScreenshotFormat format, SceShareScreenshotTapPoint tapPoint)
    {
        int32_t ret = SCE_OK;

        SceShareCaptureScreenshotParam param = {0};
        param.format = format;
        param.tapPoint = tapPoint;

        SceShareRequestId requestId;
        ret = sceShareCaptureScreenshot(&param, &requestId);
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
        }

        return requestId;
    }

    uint64_t Main::GetRtcCurrentTick(APIResult* result)
    {
        int32_t ret = SCE_OK;

        SceRtcTick current = {0};
        ret = sceRtcGetCurrentTick(&current);
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
        }

        // Note that 1 rtc tick = 1 microsecond.
        return current.tick;
    }

    int32_t Main::CaptureVideoClipRelative(APIResult* result, int32_t startTime, int32_t endTime)
    {
        int32_t ret = SCE_OK;

        SceShareCaptureVideoClipParam param = {0};
        param.thisSize = sizeof(SceShareCaptureVideoClipParam);
        param.mode = SCE_SHARE_CAPTURE_VIDEO_CLIP_PARAM_MODE_RELATIVE;
        param.recordingTime.relativeTime.startTime = startTime;
        param.recordingTime.relativeTime.endTime = endTime;

        SceShareRequestId requestId;
        ret = sceShareCaptureVideoClip(&param, &requestId);
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
        }

        return requestId;
    }

    int32_t Main::CaptureVideoClipAbsolute(APIResult* result, uint64_t startTime, uint64_t endTime)
    {
        int32_t ret = SCE_OK;

        SceShareCaptureVideoClipParam param = {0};
        param.thisSize = sizeof(SceShareCaptureVideoClipParam);
        param.mode = SCE_SHARE_CAPTURE_VIDEO_CLIP_PARAM_MODE_ABSOLUTE;
        param.recordingTime.absoluteTime.startTime.tick = startTime;
        param.recordingTime.absoluteTime.endTime.tick = endTime;

        SceShareRequestId requestId;
        ret = sceShareCaptureVideoClip(&param, &requestId);
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
        }

        return requestId;
    }

    void Main::OpenContentMenuForContent(APIResult* result, SceShareContentId contentId)
    {
        int32_t ret = sceShareOpenMenuForContent(contentId);
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
        }
    }

    void Main::GetCurrentStatus(APIResult* result, SceShareFeatureFlag featureFlag, CurrentStatus* status)
    {
        if (!status)
        {
            SCE_ERROR_RESULT(result, SCE_SHARE_LIBRARY_ERROR_INVALID_PARAM);
            return;
        }

        if (featureFlag != SCE_SHARE_FEATURE_FLAG_VIDEO_RECORDING && featureFlag != SCE_SHARE_FEATURE_FLAG_BROADCAST)
        {
            SCE_ERROR_RESULT(result, SCE_SHARE_LIBRARY_ERROR_INVALID_PARAM);
            return;
        }

        memset(status, 0, sizeof(CurrentStatus));
        SceShareCurrentStatus currentStatus;
        memset(&currentStatus, 0, sizeof(SceShareCurrentStatus));

        int32_t ret = sceShareGetCurrentStatus(featureFlag, &currentStatus);
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
            return;
        }

        if (featureFlag == SCE_SHARE_FEATURE_FLAG_VIDEO_RECORDING)
        {
            status->recording2kStatus = currentStatus.recordingStatus.recording2kStatus;
            status->recording4kStatus = currentStatus.recordingStatus.recording4kStatus;
        }
        else if (featureFlag == SCE_SHARE_FEATURE_FLAG_BROADCAST)
        {
            status->isOnAir = currentStatus.broadcastStatus.isOnAir;
        }
    }

    void Main::SetContentParam(APIResult* result, const char* contentParam)
    {
        int32_t ret = sceShareSetContentParam(contentParam);
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
        }
    }

    void Main::SetCaptureSource(APIResult* result, SceShareFeatureFlag featureFlags, const TapPoints* tapPoints)
    {
        SceShareTapPoints points = {0};
        points.video = tapPoints->video;
        points.audio = tapPoints->audio;
        int32_t ret = sceShareSetCaptureSource(featureFlags, &points);
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
        }
    }

    void Main::SetScreenshotOverlayImage(APIResult* result, const char* filePath, int32_t marginX, int32_t marginY, SceShareScreenshotOrigin origin)
    {
        int32_t ret = sceShareSetScreenshotOverlayImage(filePath, marginX, marginY, origin);
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
        }
    }

#if SCE_PROSPERO_SDK_VERSION >= 0x04000031u
    int32_t Main::CaptureScreenshotExtended(APIResult* result, int32_t format, int32_t tapPoint, const char* metadata)
    {
        SceShareCaptureScreenshotExtendedParam extendedParam = { 0 };
        extendedParam.thisSize = sizeof(extendedParam);
        extendedParam.format = format;
        extendedParam.tapPoint = tapPoint;
        extendedParam.metadata = metadata;

        SceShareRequestId requestId;
        int32_t ret = sceShareCaptureScreenshotExtended(&extendedParam, &requestId);
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
        }

        return requestId;
    }

    int32_t Main::CaptureVideoClipRelativeExtended(APIResult* result, int32_t startTime, int32_t endTime, const char* metadata)
    {

        SceShareCaptureVideoClipRecordingParam recordingParam;
        memset(&recordingParam, 0, sizeof(recordingParam));
        recordingParam.mode = SCE_SHARE_CAPTURE_VIDEO_CLIP_PARAM_MODE_RELATIVE;
        recordingParam.recordingTime.relativeTime.startTime = startTime;
        recordingParam.recordingTime.relativeTime.endTime = endTime;

        SceShareCaptureVideoClipExtendedParam extendedParam = { 0 };
        extendedParam.thisSize = sizeof(extendedParam);
        extendedParam.metadata = metadata;
        extendedParam.recordingParam = recordingParam;

        SceShareRequestId requestId;
        int32_t ret = sceShareCaptureVideoClipExtended(&extendedParam, &requestId);
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
        }

        return requestId;
    }

    int32_t Main::CaptureVideoClipAbsoluteExtended(APIResult* result, uint64_t startTime, uint64_t endTime, const char* metadata)
    {
        SceShareCaptureVideoClipRecordingParam recordingParam;
        memset(&recordingParam, 0, sizeof(recordingParam));
        recordingParam.mode = SCE_SHARE_CAPTURE_VIDEO_CLIP_PARAM_MODE_ABSOLUTE;
        recordingParam.recordingTime.absoluteTime.startTime.tick = startTime;
        recordingParam.recordingTime.absoluteTime.endTime.tick = endTime;

        SceShareCaptureVideoClipExtendedParam extendedParam = { 0 };
        extendedParam.thisSize = sizeof(extendedParam);
        extendedParam.metadata = metadata;
        extendedParam.recordingParam = recordingParam;

        SceShareRequestId requestId;
        int32_t ret = sceShareCaptureVideoClipExtended(&extendedParam, &requestId);
        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
        }

        return requestId;
    }

    void Main::SetContentParamForApplicationTitle(APIResult* result, const char* applicationTitle)
    {
         int32_t ret = sceShareSetContentParamForApplicationTitle(applicationTitle);

         if (ret != SCE_OK)
         {
             SCE_ERROR_RESULT(result, ret);
         }
    }

    SceShareFeatureFlag Main::GetRunningStatus(APIResult* result)
    {
        SceShareFeatureFlag featureFlags = 0;
        int32_t ret = sceShareGetRunningStatus(&featureFlags);

        if (ret != SCE_OK)
        {
            SCE_ERROR_RESULT(result, ret);
        }

        return featureFlags;
    }
#endif

    void Main::SetupRuntimeInterfaces()
    {

    }

    extern "C" int module_start(SceSize sz, const void* arg)
    {
        if (!ProcessPrxPluginArgs(sz, arg, "Share"))
        {
            // Failed.
            return SCE_KERNEL_START_NO_RESIDENT;
        }

        return SCE_KERNEL_START_SUCCESS;
    }
}
