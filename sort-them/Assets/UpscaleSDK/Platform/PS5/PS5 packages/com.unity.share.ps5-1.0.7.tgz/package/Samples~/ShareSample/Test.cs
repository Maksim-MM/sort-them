#if UNITY_PS5
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

using Unity.Share.PS5;

namespace PS5ShareSample
{
    /// <summary>
    /// Contains the "Test" behaviour which demonstrates and tests the varios methods and classes included in the Unity.Share.PS5 namespace.
    ///
    /// Note that for screen shots to work permission must be set in in the applications param.json file; atttribute3 must be set correctly.
    /// See https://game.develop.playstation.net/resources/documents/SDK/latest/Param_File_Editor-Users_Guide/0004.html
    /// Specifically bit 4 of attribute3 needs to be set, i.e. attribute3 is OR'd with 16.
    ///
    /// A suitable param.json file is supplied and can be set in the PS5 Player Settings either manually or by selecting
    /// the 'Set Publish Settings For PS5 Share Sample' item in the 'SCE Publishing Utils' menu.
    /// </summary>
    public class Test : MonoBehaviour
    {
        float m_1stStepDelay = 2.0f;
        float m_StepDelay = 1.0f;

        [Tooltip("Overlay image file, the path is relative to the streaming assets folder.")]
        public string m_OverlayImagePath = "overlay.png";

        int m_UpdateCount = 0;
        float m_TimeToStep = 0.0f;
        string m_LogText = "";
        int m_CurrentStep = 0;
        int m_RequestID = -1;
        bool m_PluginReady = false;
        long m_LastRecordedContentId = 0;
        int m_RequestIDForDialog = 0;

        /// <summary>
        /// enum defining test IDs.
        /// </summary>
        enum Step
        {
            Delay,
            InitializePlugin,
            GetCurrentRecordingStatus,
            GetCurrentBroadcastingStatus,
            ScreenShot,
            VideoClipRelative,
            VideoClipAbsolute,
            FeaturePermit,
            FeatureProhibit,
            StoreRequestIDForDialog,
            OpenMenuForContent,
            SetScreenshotOverlay,
            SetCaptureSource,
            SetContentParam,
            ScreenShotExt,
            VideoClipRelativeExt,
            VideoClipAbsoluteExt,
            SetContentParamForApplicationTitle,
            GetRunningStatus,
            AllDone,
        }

        /// <summary>
        /// Array of tests to be executed.
        /// </summary>
        Step[] m_Steps = new Step[]
        {
            Step.InitializePlugin, Step.Delay,
            Step.SetContentParam, Step.Delay,
            Step.SetCaptureSource, Step.Delay,
            Step.SetScreenshotOverlay, Step.Delay,
            Step.FeatureProhibit, Step.Delay,
            Step.FeaturePermit, Step.Delay,
            Step.ScreenShot, Step.Delay,
            Step.GetCurrentRecordingStatus, Step.Delay,
            Step.GetCurrentBroadcastingStatus, Step.Delay,
            Step.VideoClipRelative, Step.Delay,
            Step.GetCurrentRecordingStatus, Step.Delay,
            Step.VideoClipAbsolute, Step.StoreRequestIDForDialog, Step.Delay,
            Step.GetCurrentRecordingStatus, Step.Delay,
            Step.ScreenShotExt, Step.Delay,
            Step.VideoClipRelativeExt, Step.Delay,
            Step.VideoClipAbsoluteExt, Step.Delay,
            Step.SetContentParamForApplicationTitle, Step.Delay,
            Step.GetRunningStatus, Step.Delay,
            Step.AllDone,
        };

        /// <summary>
        /// Event handler for dislaying log messages from the share plugin.
        /// </summary>
        /// <param name="msg"></param>
        void OnLog(Unity.Share.PS5.Messages.PluginMessage msg)
        {
            OnScreenLog.Add(msg.Text);
        }

        /// <summary>
        /// Event handler for dislaying log messages from the share plugin.
        /// </summary>
        /// <param name="msg"></param>
        void OnLogWarning(Unity.Share.PS5.Messages.PluginMessage msg)
        {
            OnScreenLog.Add("WARNING: " + msg.Text);
        }


        /// <summary>
        /// Event handler for dislaying log messages from the share plugin.
        /// </summary>
        /// <param name="msg"></param>
        void OnLogError(Unity.Share.PS5.Messages.PluginMessage msg)
        {
            OnScreenLog.Add("ERROR: " + msg.Text);
        }

        /// <summary>
        /// Event handler called when share content has been created.
        /// </summary>
        /// <param name="eventData"></param>
        void OnGotContentEventData(Unity.Share.PS5.ContentEventData eventData)
        {
            string text = "OnGotContentEventData - ";
            text += $"reqId: 0x{eventData.reqId.ToString("X8")}";
            text += $", errorCode: 0x{eventData.errorCode.ToString("X8")}";
            text += $", type: {eventData.type}";
            text += $", contentID: 0x{eventData.contentId.ToString("X16")}";
            text += $", duration: {eventData.duration}";
            OnScreenLog.Add(text);

            m_LastRecordedContentId = eventData.contentId;

            if (eventData.errorCode == 0 && eventData.contentId != 0 && eventData.reqId == m_RequestIDForDialog)
            {
                OnScreenLog.Add($"Opening content menu for contentID: 0x{eventData.contentId.ToString("X16")}");
                Main.OpenMenuForContent(eventData.contentId);
            }
        }

        /// <summary>
        /// Behaviour initialisation.
        /// </summary>
        void Start()
        {
            FrameTimer.sm_LogEventHandlers += OnAddLogText;

            Main.OnLog += OnLog;
            Main.OnLogWarning += OnLogWarning;
            Main.OnLogError += OnLogError;
            Main.OnGotContentEventData += OnGotContentEventData;

            m_TimeToStep = m_1stStepDelay;

            m_OverlayImagePath = Path.Combine(Application.streamingAssetsPath, m_OverlayImagePath);
            OnScreenLog.Add($"Overlay image path: {m_OverlayImagePath}");

            if (!File.Exists(m_OverlayImagePath))
            {
                OnScreenLog.Add($"ERROR: Overlay image file not found !");
            }
        }

        /// <summary>
        /// Behaviour update.
        /// </summary>
        void Update()
        {
    #if PLATFORM_PS5
            if (m_PluginReady)
                Unity.Share.PS5.Main.Update();
#endif

            m_UpdateCount++;
            UpdateSteps();

            m_LogText = GetStepInfo();
        }

        /// <summary>
        /// Event handler, called once per frame to add log text to the FrameTimer log display.
        /// </summary>
        /// <param name="eventArgs"></param>
        public void OnAddLogText(FrameTimer.LogEventArgs eventArgs)
        {
            eventArgs.logText += m_LogText;
        }

        /// <summary>
        /// Get info about the next test/step.
        /// </summary>
        /// <returns></returns>
        string GetStepInfo()
        {
            string info = "";
            if (m_TimeToStep >= 0.0f && m_CurrentStep < m_Steps.Length)
                info += $"Next step is '{m_Steps[m_CurrentStep]}' in {m_TimeToStep} seconds\n";
            else
                info += $"All steps done\n";
            return info;
        }

        /// <summary>
        /// Build a json content preset information string for use with the SetContentParam function.
        /// </summary>
        string BuildContentParamString()
        {
            string json = "";
            json += "{";
            json += "\"version\":\"2.00\",";
            json += "\"twitter\":";
            json += "{";
            json += "\"hashtags\":\"#TW_Hashtags_A #TW_Hashtags_B\",";
            json += "\"message\":\"TW_Message\"";
            json += "},";
            json += "\"youtube\":";
            json += "{";
            json += "\"hashtags\":\"#YT_Hashtags_A #YT_Hashtags_B\",";
            json += "\"link\":\"https://youtube.com\",";
            json += "\"message\":\"YT_Message\"";
            json += "}";
            json += "}";
            return json;
        }

        /// <summary>
        /// Build a json application title info string for use with the SetContentParamForApplicationTitle function.
        /// </summary>
        string BuildContentApplicationTitleString()
        {
            string json = "";
            json += "{";
            json += "    \"version\":\"1.00\",";
            json += "    \"defaultLanguage\":\"en-US\",";
            json += "    \"en-US\":\"Application_Title_en_US\",";
            json += "    \"ja-JP\":\"日本語のアプリケーションタイトル\"";
            json += "}";
            return json;
        }

        /// <summary>
        /// Build a json metadata string for use with the CaptureScreenshotExtended, the CaptureVideoClipRelativeExtended, and the CaptureVideoClipRelativeAbsolute functions.
        /// </summary>
        string BuildMetadataString()
        {
            // Build a metadata JSON string describing the content.
            string json = "";
            json += "{";
            json += "\"version\":\"1.00\",";
            json += "\"contentTitle\":\"Content Title\"";
            json += "}";
            return json;
        }

        float ExecuteCurrentStep()
        {
            float timeTillNextStep = 0.0f;

            if (m_Steps[m_CurrentStep] != Step.Delay)
            {
                OnScreenLog.Add($"Executing test step '{m_Steps[m_CurrentStep]}'");
            }

            switch(m_Steps[m_CurrentStep])
            {
                case Step.Delay:
                    timeTillNextStep = m_StepDelay;
                    break;

                case Step.InitializePlugin: // Initialise the share plugin.
#if PLATFORM_PS5
                    try
                    {
                        Unity.Share.PS5.Initialization.InitResult results = Main.Initialize();
                        OnScreenLog.Add($"Share InitResults.Intialized: {results.Initialized}");
                        OnScreenLog.Add($"                  SceSDKVersion: {results.SceSDKVersion}");
                        OnScreenLog.Add($"                  SceSDKVersionValue: {results.SceSDKVersionValue.ToString("X8")}");
                        m_PluginReady = true;
                    }
                    catch(System.Exception e)
                    {
                        OnScreenLog.Add($"Failed to initialize the plugin\n{e}");
                    }
#endif
                    break;

                case Step.SetContentParam:  // Set preset information for sharing content.
#if PLATFORM_PS5
                    if (m_PluginReady)
                    {
                        Main.SetContentParam(BuildContentParamString());
                        OnScreenLog.Add($"Called SetContentParam");
                    }
#endif
                    break;

                case Step.SetScreenshotOverlay: // Set the image to be overlayed on screen-shots.
#if PLATFORM_PS5
                    if (m_PluginReady)
                    {
                        Main.FeatureProhibit(FeatureFlag.SCE_SHARE_FEATURE_FLAG_SCREENSHARE);
                        OnScreenLog.Add($"SetScreenshotOverlayImage");
                        Main.SetScreenshotOverlayImage(m_OverlayImagePath, 16, 16, ScreenshotOrigin.SCE_SHARE_SCREENSHOT_ORIGIN_CENTER_CENTER);
                        Main.FeaturePermit(FeatureFlag.SCE_SHARE_FEATURE_FLAG_SCREENSHARE);
                    }
#endif
                    break;

                case Step.SetCaptureSource: // Set the video capture source.
#if PLATFORM_PS5
                    if (m_PluginReady)
                    {
                        TapPoints tapPoints;
                        tapPoints.video = VideoTapPoint.SCE_SHARE_VIDEO_TAP_POINT_AUTO;
                        tapPoints.audio = AudioTapPoint.SCE_SHARE_AUDIO_TAP_POINT_MAIN;
                        OnScreenLog.Add($"SetCaptureSource");
                        Main.SetCaptureSource(FeatureFlag.SCE_SHARE_FEATURE_FLAG_VIDEO_RECORDING | FeatureFlag.SCE_SHARE_FEATURE_FLAG_BROADCAST, tapPoints);
                    }
#endif
                    break;

                case Step.FeaturePermit:    // Set the permited share feature flags.
#if PLATFORM_PS5
                    if (m_PluginReady)
                    {
                        FeatureFlag flags = FeatureFlag.SCE_SHARE_FEATURE_FLAG_SCREENSHARE | FeatureFlag.SCE_SHARE_FEATURE_FLAG_VIDEO_RECORDING;
                        OnScreenLog.Add($"FeaturePermit: 0x{flags.ToString("X")}");
                        Main.FeaturePermit(flags);
                    }
#endif
                    break;

                case Step.FeatureProhibit:    // Set the prohibited share feature flags.
#if PLATFORM_PS5
                    if (m_PluginReady)
                    {
                        FeatureFlag flags = FeatureFlag.SCE_SHARE_FEATURE_FLAG_SCREENSHARE | FeatureFlag.SCE_SHARE_FEATURE_FLAG_VIDEO_RECORDING;
                        OnScreenLog.Add($"FeatureProhibit: 0x{flags.ToString("X")}");
                        Main.FeatureProhibit(flags);
                    }
#endif
                    break;

                case Step.GetCurrentRecordingStatus:    // Get the current video recording status.
#if PLATFORM_PS5
                    if (m_PluginReady)
                    {
                        CurrentStatus status;
                        Main.GetCurrentStatus(FeatureFlag.SCE_SHARE_FEATURE_FLAG_VIDEO_RECORDING, out status);
                        OnScreenLog.Add($"GetCurrentStatus  2K: {status.recording2kStatus}, 4K: {status.recording4kStatus}");
                    }
#endif
                    break;

                case Step.GetCurrentBroadcastingStatus: // Get the current broadcast status.
#if PLATFORM_PS5
                    if (m_PluginReady)
                    {
                        CurrentStatus status;
                        Main.GetCurrentStatus(FeatureFlag.SCE_SHARE_FEATURE_FLAG_BROADCAST, out status);
                        OnScreenLog.Add($"GetCurrentStatus  OnAir: {status.isOnAir}");
                    }
#endif
                    break;

                case Step.ScreenShot:   // Trigger a screen-shot.
#if PLATFORM_PS5
                    if (m_PluginReady)
                    {
                        m_RequestID = Main.CaptureScreenshot(ScreenshotFormat.SCE_SHARE_SCREENSHOT_FORMAT_AUTO, ScreenshotTapPoint.SCE_SHARE_SCREENSHOT_TAP_POINT_MAIN_ONLY);
                        OnScreenLog.Add($"CaptureScreenshot requestId: 0x{m_RequestID.ToString("X8")}\n");
                    }
#endif
                    break;

                case Step.VideoClipRelative:    // Start video recording with time range relative to the current tick.
#if PLATFORM_PS5
                    if (m_PluginReady)
                    {
                        // Record a video clip with start and end time relative to the current time.
                        m_RequestID = Main.CaptureVideoClipRelative(-5, 5); // Relative time is in seconds.
                        OnScreenLog.Add($"CaptureVideoClipRelative requestId: 0x{m_RequestID.ToString("X8")}\n");
                    }
#endif
                    break;

                case Step.VideoClipAbsolute:    // Start video recording with absolute time range.
#if PLATFORM_PS5
                    if (m_PluginReady)
                    {
                        // Record a video clip with absolute start and end times.
                        ulong rtcTicks = Main.GetRtcCurrentTick();  // For the sake of testing we'll calculate the absolute times relative to the current rtc time.
                        ulong start = rtcTicks - 5 * 1000 * 1000;
                        ulong end = rtcTicks + 5 * 1000 * 1000;
                        m_RequestID = Main.CaptureVideoClipAbsolute(start, end);
                        OnScreenLog.Add($"CaptureVideoClipAbsolute requestId: 0x{m_RequestID.ToString("X8")}\n");
                    }
#endif
                    break;

                case Step.ScreenShotExt:   // Trigger a screen-shot.
#if PLATFORM_PS5
                    if (m_PluginReady)
                    {
                        string metadata = BuildMetadataString();
                        m_RequestID = Main.CaptureScreenshotExtended(ScreenshotFormat.SCE_SHARE_SCREENSHOT_FORMAT_AUTO, ScreenshotTapPoint.SCE_SHARE_SCREENSHOT_TAP_POINT_MAIN_ONLY, metadata);
                        OnScreenLog.Add($"CaptureScreenshotExtended requestId: 0x{m_RequestID.ToString("X8")}\n");
                    }
#endif
                    break;

                case Step.VideoClipRelativeExt:    // Start video recording with time range relative to the current tick.
#if PLATFORM_PS5
                    if (m_PluginReady)
                    {
                        // Record a video clip with start and end time relative to the current time.
                        string metadata = BuildMetadataString();
                        m_RequestID = Main.CaptureVideoClipRelativeExtended(-5, 5, metadata); // Relative time is in seconds.
                        OnScreenLog.Add($"CaptureVideoClipRelativeExtended requestId: 0x{m_RequestID.ToString("X8")}\n");
                    }
#endif
                    break;

                case Step.VideoClipAbsoluteExt:    // Start video recording with absolute time range.
#if PLATFORM_PS5
                    if (m_PluginReady)
                    {
                        // Record a video clip with absolute start and end times.
                        ulong rtcTicks = Main.GetRtcCurrentTick();  // For the sake of testing we'll calculate the absolute times relative to the current rtc time.
                        ulong start = rtcTicks - 5 * 1000 * 1000;
                        ulong end = rtcTicks + 5 * 1000 * 1000;
                        string metadata = BuildMetadataString();
                        m_RequestID = Main.CaptureVideoClipAbsoluteExtended(start, end, metadata);
                        OnScreenLog.Add($"CaptureVideoClipAbsoluteExtended requestId: 0x{m_RequestID.ToString("X8")}\n");
                    }
#endif
                    break;

                case Step.SetContentParamForApplicationTitle:    // Start video recording with absolute time range.
#if PLATFORM_PS5
                    if (m_PluginReady)
                    {
                        Main.SetContentParamForApplicationTitle(BuildContentApplicationTitleString());
                        OnScreenLog.Add("SetContentParamForApplicationTitle");
                    }
#endif
                    break;

                case Step.GetRunningStatus:
#if PLATFORM_PS5
                    if (m_PluginReady)
                    {
                        FeatureFlag status = Main.GetRunningStatus();
                        OnScreenLog.Add($"Running status: {status}\n");
                    }
#endif
                    break;

                case Step.StoreRequestIDForDialog:
                    // Store the last request ID for use with the content share dialog, the OnGotContentEventData function
                    // will open the dialog for the associated content ID when this request ID completes.
                    m_RequestIDForDialog = m_RequestID;
                    OnScreenLog.Add($" Stored requestID for dialog: 0x{m_RequestIDForDialog.ToString("X8")}");
                    break;

                case Step.AllDone:          // All steps done, stop now.
                    timeTillNextStep = -1.0f;   // Last step so stop stepping.
                    break;

                default:
                    OnScreenLog.Add($"...did nothing");
                    break;
            }

            return timeTillNextStep;
        }


        /// <summary>
        /// Update and execute tests.
        /// </summary>
        void UpdateSteps()
        {
            if (!UnityEngine.Rendering.SplashScreen.isFinished)
            {
                return;
            }

            if (m_TimeToStep >= 0.0f)
            {
                m_TimeToStep = m_TimeToStep - Time.deltaTime;
                if (m_TimeToStep < 0.0f)
                {
                    do
                    {
                        try
                        {
                            m_TimeToStep = ExecuteCurrentStep();
                        }
                        catch(Unity.Share.PS5.Core.ShareException e)
                        {
                            m_TimeToStep = 0.0f;
                            OnScreenLog.Add($"{e}");
                        }
                        m_CurrentStep++;
                    } while (m_TimeToStep == 0.0f && m_CurrentStep < m_Steps.Length);
                }
            }
        }
    }
}
#endif
