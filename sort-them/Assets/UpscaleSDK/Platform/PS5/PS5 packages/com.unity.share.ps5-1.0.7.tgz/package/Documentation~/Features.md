# C# API features for Playstation 5 Share Library

Sony provides the native Playstation 5 (PS5) Share Library in C++. The PS5 Share Library package gives you access to the PS5 Share system in C#, so you can use it for development in the Unity Editor. 

This page gives you an overview of the main C# API features provided with the PS5 Share Library package. To view these features in a project, see the [Share sample project](Sample.md). 

The following table outlines each API class and its use. For further information, see the PS5 Share Library package’s [scripting reference](../api/Unity.Share.PS5.Main.html) documentation.  

|**API class**|**Description**|
|---|---|---|
[Main.Initialize](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_Initialize)|Initializes the PS5 Share system. You must initialize the Share system before you can use it. For more information see, [Initializing the PS5 Share Library](Initialization.md)|
[Main.Terminate](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_Terminate)|Shuts down the Share system and unloads the native Share Library|
[Main.Update](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_Update)|Updates the PS5 Share system’s internal state and monitors content creation. |
[Main.SetScreenshotOverlayImage](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_SetScreenshotOverlayImage_System_String_System_Int32_System_Int32_Unity_Share_PS5_ScreenshotOrigin_)|Sets a screenshot overlay image.|
|[Main.SetContentParam](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_SetContentParam_System_String_)|Sets preset information for sharing content.|
|[Main.SetCaptureSource](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_SetCaptureSource_Unity_Share_PS5_FeatureFlag_Unity_Share_PS5_TapPoints_)|Sets share capture tap points.|
|[Main.FeaturePermit](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_FeaturePermit_Unity_Share_PS5_FeatureFlag_)|Sets permitted PS5 Share system features. |
|[Main.FeatureProhibit](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_FeatureProhibit_Unity_Share_PS5_FeatureFlag_)|Sets prohibited PS5 Share system features.|
|[Main.CaptureScreenshot](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_CaptureScreenshot_Unity_Share_PS5_ScreenshotFormat_Unity_Share_PS5_ScreenshotTapPoint_)|Captures a screenshot.|
[Main.CaptureVideoClipRelative](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_CaptureVideoClipRelative_System_Int32_System_Int32_)|Captures a video clip with start and end times relative to the current time.
[Main.CaptureVideoClipAbsolute](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_CaptureVideoClipAbsolute_System_UInt64_System_UInt64_)|Captures a video clip with absolute start and end times.|
[Main.GetCurrentStatus](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_GetCurrentStatus_Unity_Share_PS5_FeatureFlag_Unity_Share_PS5_CurrentStatus__)|Gets the state of a feature related to the PS5 Share system.|
[Main.OpenMenuForContent](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_OpenMenuForContent_System_Int64_)|Opens the Share menu for the specified content.|
[Main.GetRtcCurrentTick](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_GetRtcCurrentTick)|Gets the current real-time clock tick value|


  

