
# Using the Share sample project

Use the Share sample project to view example scripts and the Share [C# feature API](Features.md) in a project setting. 


## Installation
 ![](Images/share-sample-install.png)

To install the sample project, follow these steps:

1. Install the PS5 Share package using the steps provided in [Getting Started with the PS5 Share package](index.md). 
2. Open the Package Manager window (**Window** > **Package Manager**) and navigate to the Share PS5 package panel.
3. Select** Import**. 
4. Change your build target to PS5. To do this, open the Build Settings window ( **File** > **Build Settings**), select the **Playstation 5** build target, and select **Switch Platform**.
5. Installing the Share sample project adds a **SCE Publishing Utils** menu item to Unity's top menu bar. Open the **SCE Publishing Utils** menu and enable **Set Publish Settings for PS5 Share Sample**. This item configures the Share sample project’s player settings and assets before you build for the first time. 
6. Open the Share sample Unity scene in the **Project Window** > **Assets folder** (**Assets** > **Samples** > **Share** **PS5** > **version number** > **Share** **Sample**). 
The version number depends on the package version.
7. To add the scene to the **Scenes in Build** panel, in the Build Settings window **(File** > **Build Settings**), select **Add Open Scenes**. Make sure the Share Sample scene is scene 0.
8. To build your project and run it on your PS5 Development Kit, select **Build and Run**.

To view the Share sample project scripts go to **Project Window** > **Assets** > **Samples** > **Share PS5** > **version** > **Share Sample** > **SonyExamples**. 
