using System;
using System.Runtime.InteropServices;
using System.Text;

namespace Unity.Share.PS5
{
    /// <summary>
    /// Message handling from the native plugin.
    /// </summary>
    public class Messages
    {
        // Messages.
        [DllImport(LibraryInfo.LibraryName)] [return:MarshalAs(UnmanagedType.I1)]
        private static extern bool PrxShareHasMessage();
        [DllImport(LibraryInfo.LibraryName)] [return:MarshalAs(UnmanagedType.I1)]
        private static extern bool PrxShareGetFirstMessage(out PluginMessage msg);
        [DllImport(LibraryInfo.LibraryName)] [return:MarshalAs(UnmanagedType.I1)]
        private static extern bool PrxShareRemoveFirstMessage();

        /// <summary>
        /// Message types.
        /// </summary>
        public enum MessageType
        {
            /// <summary> No message type set. </summary>
            kShare_NotSet,
            /// <summary> Log message from the plugin. </summary>
            kShare_Log,
            /// <summary> Warning message from the plugin. </summary>
            kShare_LogWarning,
            /// <summary> Error message from the plugin. </summary>
            kShare_LogError,
            /// <summary> Share request has completed and the result is ready. </summary>
            kShare_GotRequestResult,		// Share request has completed and the result is ready.
        }

        /// <summary>
        /// Event handler for messages from the plugin.
        /// </summary>
        /// <param name="msg">The message from the plugin</param>
        public delegate void EventHandler(PluginMessage msg);

        /// <summary>
        /// Message structure from the plugin.
        /// </summary>
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
        public struct PluginMessage
        {
            /// <summary>
            /// Message type.
            /// </summary>
            public MessageType type;

            /// <summary>
            /// Size of data.
            /// </summary>
            public int dataSize;

            /// <summary>
            /// Pointer to data.
            /// </summary>
            public IntPtr data;

            /// <summary>
            /// Text message from the plugin.
            /// </summary>
            public string Text
            {
                get
                {
                    switch (type)
                    {
                        case MessageType.kShare_Log:
                        case MessageType.kShare_LogWarning:
                        case MessageType.kShare_LogError:
                            return Marshal.PtrToStringAnsi(data);
                    }
                    return "no text";
                }
            }

            /// <summary>
            /// Integer data from the plugin.
            /// </summary>
            public int Int
            {
                get
                {
                    switch (type)
                    {

                        case MessageType.kShare_GotRequestResult:
                            return (int)data;
                    }
                    return 0;
                }
            }
        };

        /// <summary>
        /// Check if there are any messages from the plugin.
        /// </summary>
        /// <returns>Returns true if has message</returns>
        public static bool HasMessage()
        {
            return PrxShareHasMessage();
        }

        /// <summary>
        /// Remove the first message from the queue.
        /// </summary>
        public static void RemoveFirstMessage()
        {
            PrxShareRemoveFirstMessage();
        }

        /// <summary>
        /// Get the first message from the queue.
        /// </summary>
        /// <param name="msg">Returns the message from the queue</param>
        public static void GetFirstMessage(out PluginMessage msg)
        {
            PrxShareGetFirstMessage(out msg);
        }
    }
}
