
# Using the PS5 Share Library package

The Playstation 5 (PS5) Share Library package enables you to create video clips and screenshots inside your application. This document shows how to use the Unity for PS5 API to capture screenshots, capture video clips and open the Share system menu window.  To view the following APIs in a project setting see the [Share Sample](Sample.md) project. 


## Capturing screenshots

Use the following APIs to capture screenshots in your application. You can use these APIs anywhere in your code. For a full list of the PS5 Share Library API features, see the [C# API features list](Features.md) documentation.


**Note**: When you use the PS5 Share Library to capture screenshots,  Main.CaptureScreenshot returns `RequestID`. 
|**Related APIs**|
|---|
|[Main.SetScreenshotOverlayImage](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_SetScreenshotOverlayImage_System_String_System_Int32_System_Int32_Unity_Share_PS5_ScreenshotOrigin_)|
|[Main.CaptureScreenshot](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_CaptureScreenshot_Unity_Share_PS5_ScreenshotFormat_Unity_Share_PS5_ScreenshotTapPoint_)|


To trigger a screenshot call the [Main.CaptureScreenshot](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_CaptureScreenshot_Unity_Share_PS5_ScreenshotFormat_Unity_Share_PS5_ScreenshotTapPoint_) API. See the example code below: 

```

int m_RequestID = Main.CaptureScreenshot(ScreenshotFormat.SCE_SHARE_SCREENSHOT_FORMAT_AUTO, ScreenshotTapPoint.SCE_SHARE_SCREENSHOT_TAP_POINT_MAIN_ONLY);

```

You can specify an image to overlay the captured screenshot with the [Main.SetScreenshotOverlayImage](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_SetScreenshotOverlayImage_System_String_System_Int32_System_Int32_Unity_Share_PS5_ScreenshotOrigin_) API. See the example code below:

```

// m_OverlayImagePath is the path to the .png image file used for the overlay.

Main.SetScreenshotOverlayImage(m_OverlayImagePath, 16, 16, ScreenshotOrigin.SCE_SHARE_SCREENSHOT_ORIGIN_CENTER_CENTER);

```

The Share Library performs screenshot captures asynchronously. To see if your application has successfully captured a screenshot, add the `RequestID` to a [Main.OnGotContentEventData](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_OnGotContentEventData) delegate. To see this in a project setting see the [Share Sample](Sample.md) project. 


## Capturing video clips

Use the following APIs to capture video clips in your application. You can use these APIs anywhere in your code. For a full list of feature APIs and definitions see the [C# API features](Features.md) documentation. 

**Note**: When you use the PS5 Share Library to capture video clips, [Main.CaptureVideoClipAbsolute](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_CaptureVideoClipAbsolute_System_UInt64_System_UInt64_) and [Main.CaptureVideoClipRelative](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_CaptureVideoClipRelative_System_Int32_System_Int32_) return `RequestID`. 

|**Related APIs**|
|---|
|[Main.SetCaptureSource](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_SetCaptureSource_Unity_Share_PS5_FeatureFlag_Unity_Share_PS5_TapPoints_)|
|[Main.CaptureVideoClipAbsolute](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_CaptureVideoClipAbsolute_System_UInt64_System_UInt64_)|
|[Main.CaptureVideoClipRelative](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_CaptureVideoClipRelative_System_Int32_System_Int32_)|
|[Main.GetCurrentStatus](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_GetCurrentStatus_Unity_Share_PS5_FeatureFlag_Unity_Share_PS5_CurrentStatus__)|
|[Main.GetRtcCurrentTick](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_GetRtcCurrentTick)|


## Setting the capture source

Use [Main.SetCaptureSource](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_SetCaptureSource_Unity_Share_PS5_FeatureFlag_Unity_Share_PS5_TapPoints_) to set the source you want to use to capture the video clip. See the example code below: 

```

TapPoints tapPoints;

tapPoints.video = VideoTapPoint.SCE_SHARE_VIDEO_TAP_POINT_AUTO;

tapPoints.audio = AudioTapPoint.SCE_SHARE_AUDIO_TAP_POINT_MAIN;

Main.SetCaptureSource(FeatureFlag.SCE_SHARE_FEATURE_FLAG_VIDEO_RECORDING | FeatureFlag.SCE_SHARE_FEATURE_FLAG_BROADCAST, tapPoints);

```


## Capturing video clips based on time
You can capture video clips in one of two ways: 



*   In an absolute time range. 
*   In a time range relative to the current real-time clock tick.


### Capturing a video clip relative to the current time

To capture a video clip relative to the current time, use [Main.CaptureVideoClipRelative](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_CaptureVideoClipRelative_System_Int32_System_Int32_). 

```

m_RequestID = Main.CaptureVideoClipRelative(-5, 5); // Relative time is in seconds.

```


### Capturing a video clip using absolute time

To capture a video clip at an absolute time, use  [Main.CaptureVideoClipAbsolute](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_CaptureVideoClipAbsolute_System_UInt64_System_UInt64_). 

```

ulong rtcTicks = Main.GetRtcCurrentTick();  // calculate the absolute times relative to the current real-time click (rtc) time.

ulong start = rtcTicks - 5 * 1000 * 1000;

ulong end = rtcTicks + 5 * 1000 * 1000;

m_RequestID = Main.CaptureVideoClipAbsolute(start, end);

```


## Getting the current recording status

To see your application’s recording status, use [Main.GetCurrentStatus](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_GetCurrentStatus_Unity_Share_PS5_FeatureFlag_Unity_Share_PS5_CurrentStatus__), then to view the status use OnScreenLog.Add. See the example code below: 

```

CurrentStatus status;

Main.GetCurrentStatus(FeatureFlag.SCE_SHARE_FEATURE_FLAG_VIDEO_RECORDING, out status);

OnScreenLog.Add($"Status  2K: {status.recording2kStatus}, 4K: {status.recording4kStatus}");

```

The Share Library performs video clips captures asynchronously. To see if your application has successfully captured a screenshot, add the RequestID to a [Main.OnGotContentEventData](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_OnGotContentEventData) delegate.  To see this in a project setting see the [Share Sample](Sample.md) project. 


## Opening the PS5 Share Library menu window

The PS5 Share Library dialog enables the application’s end user to share the screenshots or video clips captured inside the application. 

|**Related APIs**|
|---|
|[Main.OpenMenuForContent](../api/Unity.Share.PS5.Main.html#Unity_Share_PS5_Main_OpenMenuForContent_System_Int64_)|

If you want to test the menu window in Unity, in the PS5 Target Settings, you must enable **Sharing Test from Share Function**. You can do this from inside the PS5 SDK tool set. Go to **PS5 Target Settings** > **Debug Settings** > **Share** > **Contents**, then select **Sharing Test from Share Function**.  

To test the share menu window with content recorded from inside your application see the following example code: 

```

Main.OpenMenuForContent(m_LastRecordedContentId);   // Open the Share content menu window with the last piece of content captured.

```
