using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Unity.Share.PS5.Editor")]
[assembly: InternalsVisibleTo("Unity.Share.PS5.Tests.Editor")]
