#pragma once

#include <sdk_version.h>
#include "../Includes/PluginCommonIncludes.h"
#include <share.h>

namespace Share
{
    struct InitResult
    {
    public:
        bool initialized;
        UInt32 sceSDKVersion; // SCE_PROSPERO_SDK_VERSION 

        InitResult()
        {
            initialized = false;
        }
    };

    struct ContentEventData
    {
        SceShareRequestId reqId;
        SceShareContentEventType type;
        int32_t errorCode;
        SceShareContentId contentId;
        int32_t duration;
    };

    struct CurrentStatus
    {
        SceShareRecordingStatus recording2kStatus;
        SceShareRecordingStatus recording4kStatus;
        uint32_t isOnAir;
    };

    struct TapPoints
    {
        SceShareVideoTapPoint video;
        SceShareAudioTapPoint audio;
    };

    class Main
    {
    public:

    private:

        static bool s_Initialised;

    public:

        static void Initialize(InitResult& initResult, APIResult* result);
        static void Terminate(APIResult* result);
        static void FeaturePermit(APIResult* result, SceShareFeatureFlag featureFlags);
        static void FeatureProhibit(APIResult* result, SceShareFeatureFlag featureFlags);
        static int32_t CaptureScreenshot(APIResult* result, SceShareScreenshotFormat format, SceShareScreenshotTapPoint tapPoint);
        static uint64_t GetRtcCurrentTick(APIResult* result);
        static int32_t CaptureVideoClipRelative(APIResult* result, int32_t startTime, int32_t endTime);
        static int32_t CaptureVideoClipAbsolute(APIResult* result, uint64_t startTime, uint64_t endTime);
        static void OpenContentMenuForContent(APIResult* result, SceShareContentId contentId);
        static void GetCurrentStatus(APIResult* result, SceShareFeatureFlag featureFlag, CurrentStatus* status);
        static void SetContentParam(APIResult* result, const char* contentParam);
        static void SetCaptureSource(APIResult* result, SceShareFeatureFlag featureFlags, const TapPoints* tapPoints);
        static void SetScreenshotOverlayImage(APIResult* result, const char *filePath, int32_t marginX, int32_t marginY, SceShareScreenshotOrigin origin);

#if SCE_PROSPERO_SDK_VERSION >= 0x04000031u
        static int32_t CaptureScreenshotExtended(APIResult* result, int32_t format, int32_t tapPoint, const char* metadata);
        static int32_t CaptureVideoClipRelativeExtended(APIResult* result, int32_t startTime, int32_t endTime, const char* metadata);
        static int32_t CaptureVideoClipAbsoluteExtended(APIResult* result, uint64_t startTime, uint64_t endTime, const char* metadata);
        static void SetContentParamForApplicationTitle(APIResult* result, const char* applicationTitle);
        static SceShareFeatureFlag GetRunningStatus(APIResult* result);
#endif

    private:
        static void SetupRuntimeInterfaces();
    };
}
