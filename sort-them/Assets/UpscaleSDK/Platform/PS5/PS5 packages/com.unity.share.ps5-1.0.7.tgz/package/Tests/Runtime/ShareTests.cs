﻿#if UNITY_PS5
using UnityEngine;
using UnityEngine.TestTools;
using NUnit.Framework;
using System.Collections;
using UnityEngine.PS5;
using System;
using System.IO;
using System.Collections.Generic;
using Unity.Share.PS5;
using Unity.Share.PS5.Core;

namespace ShareTests
{
    public partial class Tests : BaseTestFramework
    {
        [UnityTest, Order(30), Description("Create Share")]
        public IEnumerator C_CreateShare()
        {
            yield return new WaitUntil(IsInitialized);

            Assert.AreEqual(IsInitialized(), true);

            Debug.Log("Create Share finished");
        }
    }
}
#endif

