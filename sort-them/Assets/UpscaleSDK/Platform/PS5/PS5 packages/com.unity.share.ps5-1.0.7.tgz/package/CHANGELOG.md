# Changelog
All notable changes to the package will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

Due to package verification, the latest version below is the unpublished version and the date is meaningless.
however, it has to be formatted properly to pass verification tests.

## [1.0.7] - 2026-01-13

### Changed

- Updated links in the documentation from Unity DevNet resources to Unity Discussions.

## [1.0.6] - 2025-10-22

### Changed
- Signature files have been updated
- Updated XML documentation for all public APIs.
- Updated to support SDK 12

### Fixed
- Fixed a bug that caused the native PRX to fail to recompile when upgrading to a new package .tgz.

## [1.0.5] - 2024-08-22

### Fixed
- Fixed a linker error that could occour on recent Unity versions

## [1.0.4] - 2024-04-16

### Fixed
- Fixed a null reference exception that could occur when creating a build for Windows IL2CPP in 2021.3

## [1.0.3] - 2024-02-26

### Fixed
- Fixed a infinite build loop that could occur when an error was thrown during serialization (e.g shader compilation)

## [1.0.2] - 2024-01-10

### Fixed
   - Fixed an issue where the pacakge would invalidate the PackageCache when building and the package was added from a UMP Server
   - Fixed an issue where absoulte paths in the generated cpp would dirty source control when no cotents of the file has changed
   - Fixed an issue where compiling for PS5 when PS5 was not the selected platform would result in the package PRX (or cpp replacement) not being generated

### Changed
   - Instead of a pre-processed cpp source file generated in the package folder, the package now generates a prx in the Library/SoruceGeneratedPlugins folder which is added to the build

## [1.0.1] - 2023-10-18

### Fixed
   - Stop editor build script executing when an non-PlayStation platform is being built

## [1.0.0] - 2023-09-04
   - New package format.

## [0.0.6] - 2023-04-06

### Added
   - Added support for SDK 7.0

## [0.0.5] - 2022-10-19

### Added
   - Added support for SDK 6.0
   - Added support for SDK 5.0

## [0.0.4] - 2021-11-19
### Added
   - Support for SDK 4.0
   - Added the following functions which are supported by the Share library in SDK 4.0...
      * CaptureScreenshotExtended
      * CaptureVideoClipRelativeExtended
      * CaptureVideoClipAbsoluteExtended
      * SetContentParamForApplicationTitle
      * GetRunningStatus


## [0.0.3] - 2021-07-14
### Fixed
   - Fixed compilation errors if the package is embedded directly into a projects Packages folder.

## [0.0.2] - 2021-07-13

### Added
   - Added support for SDK 3.0

## [0.0.1] - 2021-05-25

### Fixed

- Initial Version

### Changed

- Initial Version

### Added

- Initial Version
