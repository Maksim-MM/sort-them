using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

using Unity.Share.PS5.Core;
using Unity.Share.PS5.Initialization;

namespace Unity.Share.PS5
{
    /// <summary>
    /// Screenshot tap point.
    /// The constants below represent screenshot tap points. The following values can be specified as screenshot tap points.
    /// </summary>
    public enum ScreenshotTapPoint
    {
        /// <summary>Invalid value.</summary>
        SCE_SHARE_SCREENSHOT_TAP_POINT_INVALID = -1,
        /// <summary>System default output.</summary>
        SCE_SHARE_SCREENSHOT_TAP_POINT_AUTO = 0,
        /// <summary>TV output.</summary>
        SCE_SHARE_SCREENSHOT_TAP_POINT_TV = 1,
        /// <summary>EX output.</summary>
        SCE_SHARE_SCREENSHOT_TAP_POINT_EX = 2,
        /// <summary>MAIN output only.</summary>
        SCE_SHARE_SCREENSHOT_TAP_POINT_MAIN_ONLY = 3
    }

    /// <summary>
    /// Screenshot formats.
    /// The constants below represent screenshot formats.
    /// </summary>
    public enum ScreenshotFormat
    {
        /// <summary>Invalid value.</summary>
        SCE_SHARE_SCREENSHOT_FORMAT_INVALID = -1,
        /// <summary>System default format.</summary>
        SCE_SHARE_SCREENSHOT_FORMAT_AUTO = 0,
        /// <summary>2K resolution JPEG file.</summary>
        SCE_SHARE_SCREENSHOT_FORMAT_2K_JPEG = 1,
        /// <summary>4K resolution JPEG file.</summary>
        SCE_SHARE_SCREENSHOT_FORMAT_4K_JPEG = 2,
        /// <summary>2K resolution PNG file.</summary>
        SCE_SHARE_SCREENSHOT_FORMAT_2K_PNG = 11,
        /// <summary>4K resolution PNG file.</summary>
        SCE_SHARE_SCREENSHOT_FORMAT_4K_PNG = 12
    }

    /// <summary>
    /// Origin for setting an overlay image.
    /// The constants below are used for setting the origin with sceShareSetScreenshotOverlayImage().
    /// </summary>
    public enum ScreenshotOrigin
    {
        /// <summary>Upper left corner.</summary>
        SCE_SHARE_SCREENSHOT_ORIGIN_LEFT_TOP        = 1,
        /// <summary>Center of the left edge (marginY will be ignored).</summary>
        SCE_SHARE_SCREENSHOT_ORIGIN_LEFT_CENTER     = 2,
        /// <summary>Lower left corner.</summary>
        SCE_SHARE_SCREENSHOT_ORIGIN_LEFT_BOTTOM     = 3,
        /// <summary>Center of the upper edge (marginX will be ignored).</summary>
        SCE_SHARE_SCREENSHOT_ORIGIN_CENTER_TOP      = 4,
        /// <summary>Center of the screen (marginX and marginY will both be ignored).</summary>
        SCE_SHARE_SCREENSHOT_ORIGIN_CENTER_CENTER   = 5,
        /// <summary>Center of the lower edge (marginX will be ignored).</summary>
        SCE_SHARE_SCREENSHOT_ORIGIN_CENTER_BOTTOM   = 6,
        /// <summary>Upper right corner.</summary>
        SCE_SHARE_SCREENSHOT_ORIGIN_RIGHT_TOP       = 7,
        /// <summary>Center of the right edge (marginY will be ignored).</summary>
        SCE_SHARE_SCREENSHOT_ORIGIN_RIGHT_CENTER    = 8,
        /// <summary>Lower right corner.</summary>
        SCE_SHARE_SCREENSHOT_ORIGIN_RIGHT_BOTTOM    = 9
    }

    /// <summary>
    /// Recording time mode for video clip recording.
    /// The constants below represent the video clip recording time mode.
    /// </summary>
    public enum VideoClipParamMode
    {
        /// <summary>Relative time mode.</summary>
        SCE_SHARE_CAPTURE_VIDEO_CLIP_PARAM_MODE_RELATIVE = 0,
        /// <summary>Absolute time mode.</summary>
        SCE_SHARE_CAPTURE_VIDEO_CLIP_PARAM_MODE_ABSOLUTE = 1
    }

    /// <summary>
    /// Indicates the type of content creation that triggered a content event.
    /// </summary>
    public enum ContentEventType
    {
        /// <summary>Video clip creation event.</summary>
        SCE_SHARE_CONTENT_EVENT_TYPE_CAPTURE_VIDEO_CLIP	= 1,
        /// <summary>Screenshot creation event.</summary>
        SCE_SHARE_CONTENT_EVENT_TYPE_CAPTURE_SCREENSHOT	= 2
    };

    /// <summary>
    /// Contains data about content that has just been created, an object of this type is passed into an OnGotContentEventData delegate event handler if one is defined.
    /// </summary>
    public struct ContentEventData
    {
        /// <summary>Request ID.</summary>
        public int reqId;
        /// <summary>Content event type.</summary>
        public ContentEventType type;
        /// <summary>Content creation result.</summary>
        public int errorCode;
        /// <summary>Content ID.</summary>
        public long contentId;
        /// <summary>Duration of the created content (seconds).</summary>
        public int duration;
    };

    /// <summary>
    /// Types of share related features.
    /// The constants below represent types of share related features.
    /// </summary>
    public enum FeatureFlag : uint
    {
        /// <summary>Invalid share related feature.</summary>
        SCE_SHARE_FEATURE_FLAG_INVALID          = (0x00000000),
        /// <summary>Video clip recording.</summary>
        SCE_SHARE_FEATURE_FLAG_VIDEO_RECORDING  = (0x00000001),
        /// <summary>Screenshot capturing.</summary>
        SCE_SHARE_FEATURE_FLAG_SCREENSHOT       = (0x00000002),
        /// <summary>Live streaming.</summary>
        SCE_SHARE_FEATURE_FLAG_BROADCAST        = (0x00000004),
        /// <summary>Remote play.</summary>
        SCE_SHARE_FEATURE_FLAG_REMOTE_PLAY      = (0x00000008),
        /// <summary>Share Play.</summary>
        SCE_SHARE_FEATURE_FLAG_SHAREPLAY        = (0x00000010),
        /// <summary>Screen share.</summary>
        SCE_SHARE_FEATURE_FLAG_SCREENSHARE      = (0x00000020),
        /// <summary>All share related features.</summary>
        SCE_SHARE_FEATURE_FLAG_ALL              = (0xFFFFFFFF)
    }

    /// <summary>
    /// Video clip recording status.
    /// </summary>
    public enum RecordingStatus : uint
    {
        /// <summary>Recording stopped.</summary>
        SCE_SHARE_RECORDING_STATUS_NOT_RECORDING        = (0x00),
        /// <summary>Recording paused.</summary>
        SCE_SHARE_RECORDING_STATUS_PAUSED               = (0x01),
        /// <summary>Recording.</summary>
        SCE_SHARE_RECORDING_STATUS_RUNNING              = (0x02)
    }

    /// <summary>
    /// Share related feature status.
    /// </summary>
    public struct CurrentStatus
    {
        /// <summary>2K resolution recording state.</summary>
	    public RecordingStatus recording2kStatus;
        /// <summary>4K resolution recording state.</summary>
	    public RecordingStatus recording4kStatus;
        readonly uint _isOnAir;
        /// <summary>Whether or not live streaming is being performed.</summary>
        public bool isOnAir { get { return !(_isOnAir == 0); } }
    }

    /// <summary>
    /// Video output tap points.
    /// The constants below represent video output tap points. The following values can be specified as video output tap points.
    /// </summary>
    public enum VideoTapPoint
    {
        /// <summary>Invalid value</summary>
        SCE_SHARE_VIDEO_TAP_POINT_INVALID       = (-1),
        /// <summary>System default output</summary>
        SCE_SHARE_VIDEO_TAP_POINT_AUTO          = (0),
        /// <summary>TV output</summary>
        SCE_SHARE_VIDEO_TAP_POINT_TV            = (1),
        /// <summary>EX output</summary>
        SCE_SHARE_VIDEO_TAP_POINT_EX            = (2),
        /// <summary>MAIN output only</summary>
        SCE_SHARE_VIDEO_TAP_POINT_MAIN_ONLY     = (3)
    }

    /// <summary>
    /// Audio output tap points.
    /// The constants below represent audio output tap points. The following values can be specified as audio output tap points.
    /// </summary>
    public enum AudioTapPoint
    {
        /// <summary>Invalid value.</summary>
        SCE_SHARE_AUDIO_TAP_POINT_INVALID   = (-1),
        /// <summary>MAIN output.</summary>
        SCE_SHARE_AUDIO_TAP_POINT_MAIN      = (0),
        /// <summary>AUX output.</summary>
        SCE_SHARE_AUDIO_TAP_POINT_AUX       = (1)
    }

    /// <summary>
    /// Output destination tap points.
    /// </summary>
    public struct TapPoints
    {
        /// <summary>Video output tap point.</summary>
        public VideoTapPoint video;
        /// <summary>Audio output tap point.</summary>
        public AudioTapPoint audio;
    };

    /// <summary>
    /// Main entry point to the Share plug-in and initialization.
    /// </summary>
    public class Main
    {
        /// <summary>
        /// Content creation delegate.
        /// </summary>
        public delegate void ContentEventHandler(ContentEventData eventData);

        /// <summary>
        /// Content creation delagate event handler
        /// Subscribe to this handler to get a callback when some content has been created, e.g. a screenshot or video clip.
        /// </summary>
        public static event ContentEventHandler OnGotContentEventData;

        /// <summary>
        /// Log message event handler.
        /// Subscribe to this handler to get a callback when a log message is ready to be displayed.
        /// </summary>
        public static event Messages.EventHandler OnLog;

        /// <summary>
        /// Warning log message event handler.
        /// Subscribe to this handler to get a callback when a warning log message is ready to be displayed.
        /// </summary>
        public static event Messages.EventHandler OnLogWarning;

        /// <summary>
        /// Error log message event handler.
        /// Subscribe to this handler to get a callback when an error log message is ready to be displayed.
        /// </summary>
        public static event Messages.EventHandler OnLogError;

        // Initialisation.
        [DllImport(LibraryInfo.LibraryName)]
        private static extern void PrxShareInitialize(out NativeInitResult nativeResult, out APIResult result);

        [DllImport(LibraryInfo.LibraryName)]
        private static extern void PrxShareTerminate(out APIResult result);

        [DllImport(LibraryInfo.LibraryName)]
        private static extern void PrxShareFeaturePermit(out APIResult result, uint featureFlags);

        [DllImport(LibraryInfo.LibraryName)]
        private static extern void PrxShareFeatureProhibit(out APIResult result, uint featureFlags);

        [DllImport(LibraryInfo.LibraryName)]
        private static extern int PrxShareCaptureScreenshot(out APIResult result, int format, int tapPoint);

        [DllImport(LibraryInfo.LibraryName)]
        private static extern ulong PrxShareGetRtcCurrentTick(out APIResult result);

        [DllImport(LibraryInfo.LibraryName)]
        private static extern int PrxShareCaptureVideoClipRelative(out APIResult result, int startTime, int endTime);

        [DllImport(LibraryInfo.LibraryName)]
        private static extern int PrxShareCaptureVideoClipAbsolute(out APIResult result, ulong startTime, ulong endTime);

        [DllImport(LibraryInfo.LibraryName)]
        private static extern void PrxShareOpenMenuForContent(out APIResult result, long contentId);

        [DllImport(LibraryInfo.LibraryName)]
        private static extern void PrxShareGetCurrentStatus(out APIResult result, uint featureFlag, out CurrentStatus status);

        [DllImport(LibraryInfo.LibraryName)]
        private static extern void PrxShareSetContentParam(out APIResult result, string contentParam);

        [DllImport(LibraryInfo.LibraryName)]
        private static extern void PrxShareSetCaptureSource(out APIResult result, uint featureFlags, TapPoints tapPoints);

        [DllImport(LibraryInfo.LibraryName)]
        private static extern void PrxShareSetScreenshotOverlayImage(out APIResult result, string filePath, int marginX, int marginY, ScreenshotOrigin origin);

        [DllImport(LibraryInfo.LibraryName)]
        private static extern int PrxShareCaptureScreenshotExtended(out APIResult result, int format, int tapPoint, string metadata);

        [DllImport(LibraryInfo.LibraryName)]
        private static extern int PrxShareCaptureVideoClipRelativeExtended(out APIResult result, int startTime, int endTime, string metadata);

        [DllImport(LibraryInfo.LibraryName)]
        private static extern int PrxShareCaptureVideoClipAbsoluteExtended(out APIResult result, ulong startTime, ulong endTime, string metadata);

        [DllImport(LibraryInfo.LibraryName)]
        private static extern void PrxSetContentParamForApplicationTitle(out APIResult result, string applicationTitle);

        [DllImport(LibraryInfo.LibraryName)]
        private static extern uint PrxShareGetRunningStatus(out APIResult result);

        // A global struct that shows if Share has been initialized and contains the SDK version number for the native plug-in.
        static internal InitResult sm_InitResult;

        /// <summary>
        /// Initializes the Share system.
        /// </summary>
        /// <returns>Initialization result.</returns>
        /// <exception cref="ShareException">Will throw an exception either when the request data is invalid, or an internal error has occured inside the Share plug-in.</exception>
        public static InitResult Initialize()
        {
            UnityEngine.Debug.Log("[PS5.Share] Called Initialize\n");
#if UNITY_PS5 //&& !UNITY_EDITOR
            APIResult result;
            NativeInitResult nativeResult = new NativeInitResult();

            PrxShareInitialize(out nativeResult, out result);

            if (result.RaiseException == true) throw new ShareException(result);
            sm_InitResult.Initialize(nativeResult);
#endif

            return sm_InitResult;
        }

        /// <summary>
        /// Terminates the Share system.
        /// </summary>
        public static void Terminate()
        {
            APIResult result;
            PrxShareTerminate(out result);
            if (result.RaiseException == true) throw new ShareException(result);
        }

        /// <summary>
        /// Call once per frame to update the plugin.
        /// </summary>
        public static void Update()
        {
            PumpMessages();
        }

        private static void PumpMessages()
        {
            while (Messages.HasMessage())
            {
                Messages.PluginMessage msg = new Messages.PluginMessage();
                Messages.GetFirstMessage(out msg);

                // Interpret the message and trigger corresponding events.
                switch (msg.type)
                {
                    case Messages.MessageType.kShare_Log:
                        if (OnLog != null) OnLog(msg);
                        break;

                    case Messages.MessageType.kShare_LogWarning:
                        if (OnLogWarning != null) OnLogWarning(msg);
                        break;

                    case Messages.MessageType.kShare_LogError:
                        if (OnLogError != null) OnLogError(msg);
                        break;

                    case Messages.MessageType.kShare_GotRequestResult:
                        if (OnGotContentEventData != null)
                        {
                            ContentEventData eventData = (ContentEventData)Marshal.PtrToStructure(msg.data, typeof(ContentEventData));
                            OnGotContentEventData(eventData);
                        }
                        break;
                }

                Messages.RemoveFirstMessage();
            }
        }

        /// <summary>
        /// Sets an overlay image for a screenshot.
        ///
        /// This function sets an overlay image, such as a copyright notice, to superimpose on a screenshot.
        ///
        /// The setting of an overlay image is optional; however, when setting an overlay image, make sure to call this
        /// function while screenshot capturing is prohibited.
        ///
        /// For example...
        ///
        ///    FeatureProhibit(FeatureFlag.SCE_SHARE_FEATURE_FLAG_SCREENSHARE);
        ///    SetScreenshotOverlayImage("/app0/Media/StreamingAssets/overlay.png", 16, 16, ScreenshotOrigin.SCE_SHARE_SCREENSHOT_ORIGIN_CENTER_CENTER);
        ///    FeaturePermit(FeatureFlag.SCE_SHARE_FEATURE_FLAG_SCREENSHARE);
        ///
        /// </summary>
        /// <param name="filePath">File path of the overlay image.</param>
        /// <param name="marginX">X margin to the overlay image from the origin.</param>
        /// <param name="marginY">Y margin to the overlay image from the origin.</param>
        /// <param name="origin">Origin</param>
        public static void SetScreenshotOverlayImage(string filePath, int marginX, int marginY, ScreenshotOrigin origin)
        {
            APIResult result;
            PrxShareSetScreenshotOverlayImage(out result, filePath, marginX, marginY, origin);
            if (result.RaiseException == true) throw new ShareException(result);
        }

        /// <summary>
        /// Capture a screenshot.
        ///
        /// Requests the system software to take a screenshot.
        ///
        /// When capture completes the OnGotContentEventData delegate event is called with the ID of the created
        /// content and other data.
        /// </summary>
        /// <param name="format">The desired screenshot format</param>
        /// <param name="tapPoint">The desired screenshot tap point</param>
        /// <returns>Returns a request ID</returns>
        public static int CaptureScreenshot(ScreenshotFormat format, ScreenshotTapPoint tapPoint)
        {
            APIResult result;

            int requestId = PrxShareCaptureScreenshot(out result, (int)format, (int)tapPoint);
            if (result.RaiseException == true) throw new ShareException(result);
            return requestId;
        }

        /// <summary>
        /// Capture a screenshot with metadata (requires SDK 4 or later).
        ///
        /// Requests the system software to take a screenshot.
        ///
        /// When capture completes the OnGotContentEventData delegate event is called with the ID of the created
        /// content and other data.
        /// </summary>
        /// <param name="format">The desired screenshot format</param>
        /// <param name="tapPoint">The desired screenshot tap point</param>
        /// <param name="metadata">Meta data to associate with the video.</param>
        /// <returns>Returns a request ID</returns>
        public static int CaptureScreenshotExtended(ScreenshotFormat format, ScreenshotTapPoint tapPoint, string metadata)
        {
            APIResult result;

            int requestId = PrxShareCaptureScreenshotExtended(out result, (int)format, (int)tapPoint, metadata);
            if (result.RaiseException == true) throw new ShareException(result);
            return requestId;
        }

        /// <summary>
        /// Capture a video clip.
        ///
        /// Requests the system software to take a videoclip with start and end time relative to the current time.
        ///
        /// When capture completes the OnGotContentEventData delegate event is called with the ID of the created
        /// content and other data.
        /// </summary>
        /// <param name="startTime">Relative time to start recording in seconds.</param>
        /// <param name="endTime">Relative time to end recording in seconds.</param>
        /// <returns>Returns a request ID</returns>
        public static int CaptureVideoClipRelative(int startTime, int endTime)
        {
            APIResult result;

            int requestId = PrxShareCaptureVideoClipRelative(out result, startTime, endTime);
            if (result.RaiseException == true) throw new ShareException(result);
            return requestId;
        }

        /// <summary>
        /// Capture a video clip with metadata (requires SDK 4 or later)
        ///
        /// Requests the system software to take a videoclip with start and end time relative to the current time.
        ///
        /// When capture completes the OnGotContentEventData delegate event is called with the ID of the created
        /// content and other data.
        /// </summary>
        /// <param name="startTime">Relative time to start recording in seconds.</param>
        /// <param name="endTime">Relative time to end recording in seconds.</param>
        /// <param name="metadata">Meta data to associate with the video.</param>
        /// <returns>Returns a request ID</returns>
        public static int CaptureVideoClipRelativeExtended(int startTime, int endTime, string metadata)
        {
            APIResult result;

            int requestId = PrxShareCaptureVideoClipRelativeExtended(out result, startTime, endTime, metadata);
            if (result.RaiseException == true) throw new ShareException(result);
            return requestId;
        }

        /// <summary>
        /// Get the current real time clock tick value.
        ///
        /// A utility function to get the current real time clock tick value which can be useful when calculating
        /// the start and end tick values for capturing video clips using absolute time parameters.
        /// </summary>
        /// <returns>Returns the real time clock tick value; 1 tick = 1 microsecond</returns>
        public static ulong GetRtcCurrentTick()
        {
            APIResult result;

            ulong ticks = PrxShareGetRtcCurrentTick(out result);
            if (result.RaiseException == true) throw new ShareException(result);
            return ticks;
        }

        /// <summary>
        /// Capture a video clip.
        ///
        /// Requests the system software to take a videoclip with absolute start and end time.
        ///
        /// When capture completes the OnGotContentEventData delegate event is called with the ID of the created
        /// content and other data.
        /// </summary>
        /// <param name="startTime">Absolute time to start recording in microseconds ticks.</param>
        /// <param name="endTime">Absolute time to stop recording in microsecond ticks.</param>
        /// <returns>Returns a request ID</returns>
        public static int CaptureVideoClipAbsolute(ulong startTime, ulong endTime)
        {
            APIResult result;

            int requestId = PrxShareCaptureVideoClipAbsolute(out result, startTime, endTime);
            if (result.RaiseException == true) throw new ShareException(result);
            return requestId;
        }

        /// <summary>
        /// Capture a video clip with metadata (requires SDK 4 or later)
        ///
        /// Requests the system software to take a videoclip with absolute start and end time.
        ///
        /// When capture completes the OnGotContentEventData delegate event is called with the ID of the created
        /// content and other data.
        /// </summary>
        /// <param name="startTime">Absolute time to start recording in microseconds ticks.</param>
        /// <param name="endTime">Absolute time to stop recording in microsecond ticks.</param>
        /// <param name="metadata">Meta data to associate with the video.</param>
        /// <returns>Returns a request ID</returns>
        public static int CaptureVideoClipAbsoluteExtended(ulong startTime, ulong endTime, string metadata)
        {
            APIResult result;

            int requestId = PrxShareCaptureVideoClipAbsoluteExtended(out result, startTime, endTime, metadata);
            if (result.RaiseException == true) throw new ShareException(result);
            return requestId;
        }

        /// <summary>
        /// Opens the Share menu for the specified content.
        /// </summary>
        /// <param name="contentId">ID of the content.</param>
        public static void OpenMenuForContent(long contentId)
        {
            APIResult result;

            PrxShareOpenMenuForContent(out result, contentId);
            if (result.RaiseException == true) throw new ShareException(result);
        }

        /// <summary>
        /// Gets the state of a Share-related feature
        ///
        /// This function obtains the state of the Share-related feature specified in featureFlag.
        /// The following Share-related features can be specified to featureFlag.
        ///
        /// FeatureFlag.SCE_SHARE_FEATURE_FLAG_VIDEO_RECORDING      Video clip recording
        /// FeatureFlag.SCE_SHARE_FEATURE_FLAG_BROADCAST            Live streaming
        ///
        /// </summary>
        /// <param name="featureFlag">Type of Share-related feature.</param>
        /// <param name="status">Returns the obtained Share-related feature state.</param>
        public static void GetCurrentStatus(FeatureFlag featureFlag, out CurrentStatus status)
        {
            APIResult result;

            PrxShareGetCurrentStatus(out result, (uint)featureFlag, out status);
            if (result.RaiseException == true) throw new ShareException(result);
        }

        /// <summary>
        /// Sets preset information for sharing content.
        ///
        /// This function sets preset information for sharing content.
        ///
        /// Specify the preset information in contentParam. As configurable information differs depending on the online service to which content is to be uploaded, specify a JSON document has been written according to a fixed format.
        /// Refer to Share Library Overview - Using the Library - Setting Preset Information for details on formats for preset information.
        /// When the user uses the Share feature to save content, the information set using this function will be saved along with the content.
        /// Afterward, the saved preset information will be added when the user uploads the saved content.
        /// </summary>
        /// <param name="contentParam">Preset information to set (JSON document).</param>
        public static void SetContentParam(string contentParam)
        {
            APIResult result;

            PrxShareSetContentParam(out result, contentParam);
            if (result.RaiseException == true) throw new ShareException(result);
        }

        /// <summary>
        /// Sets Share-related feature tap points.
        ///
        /// This function sets tap points for Share-related features specified in featureFlags.
        ///
        /// Multiple features can be specified to featureFlags using logical OR.
        ///
        /// The following Share-related features can be specified to featureFlags.
        ///
        ///     FeatureFlag.SCE_SHARE_FEATURE_FLAG_VIDEO_RECORDING      Video clip recording.
        ///     FeatureFlag.SCE_SHARE_FEATURE_FLAG_BROADCAST            Live streaming.
        ///     FeatureFlag.SCE_SHARE_FEATURE_FLAG_ALL                  The above Share-related features.
        ///
        /// For tapPoint, specify output destination tap points for the features specified in featureflags.
        /// Refer to SceShareTapPoints for tap points to specify.
        ///
        /// Notes:
        ///     Of the video output tap points, SCE_SHARE_VIDEO_TAP_POINT_MAIN_ONLY can only be set to SCE_SHARE_FEATURE_FLAG_VIDEO_RECORDING. An error will return if another Share-related feature or if SCE_SHARE_FEATURE_FLAG_ALL is specified.
        ///     Of the audio output tap points, SCE_SHARE_AUDIO_TAP_POINT_AUX can only be set to SCE_SHARE_FEATURE_FLAG_BROADCAST. An error will return if another Share-related feature or if SCE_SHARE_FEATURE_FLAG_ALL is specified.
        /// </summary>
        /// <param name="featureFlag">Type of Share-related feature (multiple features can be specified).</param>
        /// <param name="tapPoints">Output destination tap points.</param>
        public static void SetCaptureSource(FeatureFlag featureFlag, TapPoints tapPoints)
        {
            APIResult result;

            PrxShareSetCaptureSource(out result, (uint)featureFlag, tapPoints);
            if (result.RaiseException == true) throw new ShareException(result);
        }

        /// <summary>
        /// Permits Share-related features.
        ///
        /// This function permits the Share-related features specified in featureFlags.
        /// Multiple features can be specified to featureFlags using logical OR.
        /// The following Share-related features can be specified to featureFlags.
        ///
        /// FeatureFlag.SCE_SHARE_FEATURE_FLAG_VIDEO_RECORDING      Video clip recording
        /// FeatureFlag.SCE_SHARE_FEATURE_FLAG_SCREENSHOT           Screenshot capturing
        /// FeatureFlag.SCE_SHARE_FEATURE_FLAG_BROADCAST            Live streaming
        /// FeatureFlag.SCE_SHARE_FEATURE_FLAG_REMOTE_PLAY          Remote play
        /// FeatureFlag.SCE_SHARE_FEATURE_FLAG_SHAREPLAY            Share Play
        /// FeatureFlag.SCE_SHARE_FEATURE_FLAG_SCREENSHARE          Share Screen
        /// FeatureFlag.SCE_SHARE_FEATURE_FLAG_ALL                  The above Share-related features
        ///
        /// All Share-related features are permitted by default.
        /// </summary>
        /// <param name="featureFlag">Type of Share-related feature (multiple features can be specified).</param>
        public static void FeaturePermit(FeatureFlag featureFlag)
        {
            APIResult result;
            PrxShareFeaturePermit(out result, (uint)featureFlag);
            if (result.RaiseException == true) throw new ShareException(result);
        }

        /// <summary>
        /// Prohibits Share-related features.
        ///
        /// This function prohibits the Share-related features specified in featureFlags.
        /// Multiple features can be specified to featureFlags using logical OR.
        /// The following Share-related features can be specified to featureFlags.
        ///
        /// FeatureFlag.SCE_SHARE_FEATURE_FLAG_VIDEO_RECORDING      Video clip recording
        /// FeatureFlag.SCE_SHARE_FEATURE_FLAG_SCREENSHOT           Screenshot capturing
        /// FeatureFlag.SCE_SHARE_FEATURE_FLAG_BROADCAST            Live streaming
        /// FeatureFlag.SCE_SHARE_FEATURE_FLAG_REMOTE_PLAY          Remote play
        /// FeatureFlag.SCE_SHARE_FEATURE_FLAG_SHAREPLAY            Share Play
        /// FeatureFlag.SCE_SHARE_FEATURE_FLAG_SCREENSHARE          Share Screen
        /// FeatureFlag.SCE_SHARE_FEATURE_FLAG_ALL                  The above Share-related features
        ///
        /// All Share-related features are permitted by default.
        /// </summary>
        /// <param name="featureFlag">The feature flags to prohibit</param>
        public static void FeatureProhibit(FeatureFlag featureFlag)
        {
            APIResult result;
            PrxShareFeatureProhibit(out result, (uint)featureFlag);
            if (result.RaiseException == true) throw new ShareException(result);
        }

        /// <summary>
        /// Setting the application title when shared (requires SDK 4 or later)
        /// </summary>
        /// <param name="applicationTitle">The application title to set</param>
        public static void SetContentParamForApplicationTitle(string applicationTitle)
        {
            APIResult result;
            PrxSetContentParamForApplicationTitle(out result, applicationTitle);
            if (result.RaiseException == true) throw new ShareException(result);
        }

        /// <summary>
        /// Acquiring the operating status of share-related functions (requires SDK 4 or later)
        /// </summary>
        /// <returns>Returns the operating status of share-related functions</returns>
        public static FeatureFlag GetRunningStatus()
        {
            APIResult result;
            uint status = PrxShareGetRunningStatus(out result);
            if (result.RaiseException == true) throw new ShareException(result);
            return (FeatureFlag)status;
        }
    }
}
