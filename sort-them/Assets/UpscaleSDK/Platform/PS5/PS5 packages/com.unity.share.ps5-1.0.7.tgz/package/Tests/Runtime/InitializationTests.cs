﻿#if UNITY_PS5
using UnityEngine;
using UnityEngine.TestTools;
using NUnit.Framework;
using System.Collections;
using UnityEngine.SceneManagement;

namespace ShareTests
{
    [TestFixture, Description("Check all startup and initialization tests"), UnityPlatform(RuntimePlatform.PS5)]
    public partial class Tests : BaseTestFramework
    {
        //[PrebuildSetup("UnitTestsEditorSetup")]
        [UnityTest, Order(1), Description("Initialize Share system")]
        public IEnumerator A_InitializeShare()
        {
            yield return new WaitUntil(IsInitialized);

            Assert.AreEqual(IsInitialized(), true);

            Debug.Log(s_InitOutput);
            Debug.Log("Share initialization finished");

        }

    }
}
#endif

