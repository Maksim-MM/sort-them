# PS5 Share Library

Provides a C# API for accessing the PlayStation 5 Share library allowing applications to take screen shots and record video clips to share with others.


