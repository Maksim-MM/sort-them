using UnityEngine;
using UnityEditor;
using System.IO;
using System;

#if UNITY_PS5

namespace PS5ShareSample
{
    public class SetPlatformOptionsPS5
    {
        /// <summary>
        /// Setup streaming assets and player settings for the PS5 share sample project.
        /// </summary>
        [MenuItem("SCE Publishing Utils/Set Publish Settings For PS5 Share Sample")]
	    static void SetOptions()
	    {
		    PlayerSettings.productName = "Unity Share Example";

            // Copy the share overlay image from the SampleStreamingAssets folder to the StreamingAssets folder.
            string sourceFile = SearchForFile(Application.dataPath, "overlay", true, "Share Sample/SampleStreamingAssets");
            if (String.IsNullOrEmpty(sourceFile))
            {
                // Try alternative (currently needed if running from git repo instead of installed package).
                sourceFile = SearchForFile(Application.dataPath, "overlay", true, "Samples/ShareSample/SampleStreamingAssets");
            }
            sourceFile = sourceFile.Replace(Application.dataPath, "Assets");
            Debug.Log($"Found overlay file @ \"{sourceFile}\"");

            string streamingDir = Application.dataPath + "/StreamingAssets";
            string targetFile = streamingDir + "/overlay.png";

            targetFile = targetFile.Replace(Application.dataPath, "Assets");

            if ( Directory.Exists(streamingDir) == false)
            {
                Directory.CreateDirectory(streamingDir);
            }
            AssetDatabase.CopyAsset(sourceFile, targetFile);

            // Setup param file for the share sample.
            sourceFile = SearchForFile(Application.dataPath, "param.json", false, "Share Sample/SampleSystemFiles");
            if (String.IsNullOrEmpty(sourceFile))
            {
                // Try alternative (currently needed if running from git repo instead of installed package).
                sourceFile = SearchForFile(Application.dataPath, "param.json", false, "Samples/ShareSample/SampleSystemFiles");
            }
            sourceFile = sourceFile.Replace(Application.dataPath, "Assets");

#if UNITY_2020_1_OR_NEWER
            UnityEditor.PS5.PlayerSettings.paramFilePath = sourceFile;
#else
            UnityEditor.PlayerSettings.PS5.paramFilePath = sourceFile;
#endif

            Debug.Log($"Found param.json @ \"{sourceFile}\"");

            AssetDatabase.Refresh();
        }

        static string SearchForFile(string path, string findFilename, bool ignoreExtension, string matchPath)
        {
            var files = Directory.EnumerateFiles(path, "*.*", SearchOption.AllDirectories);

            if (!String.IsNullOrEmpty(matchPath))
                matchPath = matchPath.Replace("\\", "/");

            foreach (var file in files)
            {
                string cleanFile = file.Replace("\\", "/");
                if (!String.IsNullOrEmpty(matchPath))
                {
                    if (!cleanFile.Contains(matchPath))
                        continue;
                }

                if (ignoreExtension && Path.GetFileNameWithoutExtension(cleanFile) == findFilename)
                    return cleanFile;

                if (Path.GetFileName(cleanFile) == findFilename)
                    return cleanFile;
            }

            return "";
        }
    }
}
#endif
