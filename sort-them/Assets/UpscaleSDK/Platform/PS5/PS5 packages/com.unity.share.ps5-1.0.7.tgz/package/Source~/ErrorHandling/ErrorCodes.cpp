
#include "../Includes/PluginCommonIncludes.h"
#include <Share.h>

#define CASE_ERROR_TO_STRING(errCode) case (int)errCode: errorString = #errCode; break;

namespace Share
{
    const char* LookupSceErrorCode(int errorCode)
    {
        const char* errorString = NULL;

        switch(errorCode)
        {
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_INTERNAL)                                          // 0x81960001 Internal error occurred.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_INVALID_PARAM)	                                    // 0x81960002 An invalid parameter has been specified.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_OUT_OF_MEMORY)	                                    // 0x81960003 There is not enough memory.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_NO_SPACE)                                          // 0x81960004 There is not enough free space.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_TIMEOUT)                                           // 0x81960005 Process was timed out.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_BUSY)                                              // 0x81960006 Process is busy.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_NOT_SUPPORTED)	                                    // 0x81960007 A feature is not supported.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_NOT_SUPPORTED_FEATURE)                             // 0x81960008 Not supported feature has been specified.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_NOT_SUPPORTED_PARAM)                               // 0x81960009 Not supported parameter has been specified.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_NOT_SUPPORTED_FORMAT)                              // 0x8196000A Not supported file format has been specified.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_SESSION_NOT_FOUND)                                 // 0x8196000B The session is not found.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_NOT_INITIALIZED)	                                // 0x8196000C Library is not initialized yet.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_ALREADY_INITIALIZED)                               // 0x8196000D Library is already initialized.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_REGISTER_CONTENT)                                  // 0x8196000E Failed to register a content.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_CAPTURE_VIDEO_CLIP)                                // 0x8196000F Failed to capture a video clip.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_CAPTURE_SCREENSHOT)                                // 0x81960010 Failed to capture a screenshot.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_PROHIBITED_VIDEO_RECORDING)                        // 0x81960011 It is prohibited to record a video clip.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_PROHIBITED_SCREENSHOT)                             // 0x81960012 It is prohibited to capture a screenshot.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_ENCODING_RESOURCE_TOO_SHORT)                       // 0x81960013 There is not enough encoding resource.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_FILE_NOT_FOUND)                                    // 0x81960014 A file is not found.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_ALREADY_OPENED_MENU)                               // 0x81960015 The menu is already opened.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_INVALID_CONTENT)                                   // 0x81960016 An invalid content has been specified.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_TITLE_BACKGROUND)                                  // 0x81960017 Tried to create content or open the menu while the title was in BG state.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_PERMISSION_REQUIRED)                               // 0x81960018 Permission required to call a function.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_PARSE_JSON)                                        // 0x81960019 Failed to parse JSON.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_PROHIBITED_CHARACTER)                              // 0x8196001A Prohibited character is included.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_NOT_SUPPORTED_VERSION)                             // 0x8196001B Version is not supported.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_REQUIRED_PARAM_NOT_FOUND)                          // 0x8196001C Required parameter is not found.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_INVALID_CHARACTER)                                 // 0x8196001D Inappropriate character is included.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_INVALID_FORMAT)                                    // 0x8196001E Format is inappropriate.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_INVALID_JSON_VALUE)                                // 0x8196001F JSON value is inappropriate.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_INVALID_HASHTAGS)                                  // 0x81960020 Hashtags are inappropriate.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_INVALID_URL_SCHEME)                                // 0x81960021 URL sheme is inappropriate.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_EXCEED_CONTENT_CAPACITY_LIMIT_FOR_SHARE_LIBRARY)   // 0x81960022 Limit of capacity for Share Library is exceeded.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_EXCEED_CONTENT_CAPACITY_LIMIT_FOR_SYSTEM)          // 0x81960023 Limit of capacity for system is exceeded.
            CASE_ERROR_TO_STRING(SCE_SHARE_LIBRARY_ERROR_EXCEED_TOTAL_RECORDING_TIME_LIMIT)                 // 0x81960024 Limit of total recording time for a video clip is exceeded.
            default:
            break;
        }

        return errorString;
    }

}	// namespace Share
