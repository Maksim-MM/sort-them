# Getting started with the PS5 Share Library package

The PlayStation 5 (PS5) Share Library enables your application to create and share screenshots and video clips. 

Sony provides the native PS5 Share Library in C++. The PS5 Share Library package gives you access to the PS5 Share system in C#, so you can use it for development in the Unity Editor. 

This document is for developers who want to use the PS5 Share Library in their Unity for PS5 project without writing their own native plugin. For more details, see Sony’s [PS5 Share Library Overview](https://game.develop.playstation.net/resources/documents/SDK/latest/Share-Overview/0001.html#__document_toc_00000000).  

**Note**: This documentation does not discuss any Technical Requirements Checklist (TRC) criteria. See the Sony documentation for the latest compliance requirements.

The PS5 Share package contains the following:

*   A C# API that provides the native PS5 Share Library functionality. For an overview of the features the PS5 Share package supports, see the [C# API features list](Features.md) documentation.
*   A native .PRX plugin that provides the interface between the C# API and the native PS5 Share Library. 
*   The C++ source code for this native plugin. This lives in the `source~` folder.


## Prerequisites

To use the PS5 Share package, meet the following prerequisites: 

*   You must have the PS5 for Unity add-on installed. To do this, go to the [Unity for PlayStation 5 downloads](https://discussions.unity.com/t/unity-for-playstation-5-downloads/1568719) Unity Discussions page and select your download based on your Unity version.
*   You must have a Unity Pro subscription. If you don't have a Unity Pro subscription, please contact Unity or your Unity account manager. 
*   You must have a PS5 Development Kit or Testing Kit. For more information see Sony’s [Development Kit Setup Guide](https://game.develop.playstation.net/resources/documents/SDK/latest/DevKit-Setup_Guide/0001.html) and [Testing Kit Setup Guide](https://game.develop.playstation.net/resources/documents/SDK/latest/TestKit-Setup_Guide/__toc.html).  


# Installation

The PS5 is an NDA platform. For this reason, you can’t search for and download packages directly from the Package Manager. 

To install the com.unity.share.ps5 package:

1. Go to the [PlayStation 5 Package Downloads](https://discussions.unity.com/t/playstation-5-package-downloads/1568720) Unity Discussions page.
2. Select and download the PS5 Share Library package tarball (`.tgz`).
3. Open the Package Manager window (**Window** > **Package Manager**).
4. In the top-left corner of the window, select the **Add (+)** button.
5. Select **Add Package from Tarball**.
6. In the dialog that displays, select the PS5 Share Library package .tgz file and select **OK**.

This installs the package into your Unity project. 

You must initialize the installed PS5 Share Library package. To do this, see the [Initializing the Share library](Initialization.md) documentation.
