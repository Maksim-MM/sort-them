
namespace Unity.Share.PS5
{
    internal static class LibraryInfo
    {
        internal const string LibraryName = "Share";
        internal static string LibraryNameWithExtension => $"{LibraryName}.prx";
    }
}
