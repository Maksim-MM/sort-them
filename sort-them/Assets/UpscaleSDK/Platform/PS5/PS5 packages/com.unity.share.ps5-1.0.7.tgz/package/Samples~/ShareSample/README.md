
Warning:
--------
It is advised you only install the sample in a new project and various project settings maybe overwritten.

